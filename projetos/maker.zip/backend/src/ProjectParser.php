<?php

final class ProjectParser
{
    public function parse(array $request): array
    {
        if (!isset($request['project']) || !is_array($request['project'])) {
            throw new InvalidArgumentException('Projeto NMS ausente ou inválido.');
        }

        $project = $request['project'];

        $selection = is_array($request['selection'] ?? null) ? $request['selection'] : [];
        $music = $this->resolveMusic($project, $selection['musicId'] ?? 'none');

        $screens = $this->collectGameScreens($project);
        $playIdxs = [];
        foreach ($screens as $i => $screen) {
            if (($screen['role'] ?? '') === 'play' || ($screen['type'] ?? '') === 'background') {
                $playIdxs[] = $i;
            }
        }

        $screenData = is_array($request['screenData'] ?? null) ? $request['screenData'] : [];
        $playIdxs = [];
        foreach ($screenData as $i => $screen) {
            if (is_array($screen) && (($screen['role'] ?? '') === 'play' || ($screen['type'] ?? '') === 'background')) {
                $playIdxs[] = (int)$i;
            }
        }
        if (!$playIdxs) {
            foreach ($screens as $i => $screen) {
                if (($screen['role'] ?? '') === 'play' || ($screen['type'] ?? '') === 'background') $playIdxs[] = $i;
            }
        }

        // Stage 15: o empacotamento CHR dos sprites passa a ser responsabilidade do NGC.
        // O backend usa diretamente project.chr + project.metatiles + project.characters.
        $sprite = $this->buildSpriteContext($project, $screenData, $playIdxs);

        return [
            'project' => $project,
            'buildMode' => ($request['buildMode'] ?? 'game') === 'single' ? 'single' : 'game',
            'selection' => $selection,
            'music' => $music,
            'musicEnabled' => $music !== null,
            'musicChannelCount' => $music ? min(5, count($music['channels'] ?? [])) : 0,
            'screens' => $screens,
            'screenData' => $screenData,
            'playIdxs' => $playIdxs,
            'splashIdx' => $this->findRoleIndex($screens, 'splash', 0),
            'gameoverIdx' => $this->findRoleIndex($screens, 'gameover', max(0, count($screens) - 1)),
            'playStartIdx' => count($playIdxs) ? $playIdxs[0] : 0,
            'secondPlayScreenIdx' => count($playIdxs) > 1 ? $playIdxs[1] : null,
            'playCount' => count($playIdxs),
            'lastPlayIdx' => count($playIdxs) ? count($playIdxs) - 1 : 0,
            'sprite' => $sprite,
        ];
    }


    private function buildSpriteContext(array $project, array $screenData, array $playIdxs): array
    {
        $chars = is_array($project['characters'] ?? null) ? $project['characters'] : [];
        $packed = $this->packSpriteCHR($project, $chars);
        $charData = $packed['charData'];
        $heroIdx = 0;
        $heroFound = false;
        foreach ($chars as $i => $c) {
            if (is_array($c) && stripos((string)($c['name'] ?? ''), 'hero') !== false) {
                $heroIdx = (int)$i;
                $heroFound = true;
                break;
            }
        }
        $heroFrames = 1;
        if (isset($charData[$heroIdx]) && is_array($charData[$heroIdx])) {
            $heroFrames = max(1, count(is_array($charData[$heroIdx]['frames'] ?? null) ? $charData[$heroIdx]['frames'] : []));
        }

        $requested = (int)($project['maxInstances'] ?? 10);
        if ($requested < 1) $requested = 1;
        if ($requested > 20) $requested = 20;
        $numInstances = min($requested, 14);

        $charIndexById = [];
        $heroIds = [];
        foreach ($chars as $i => $c) {
            if (!is_array($c) || !isset($c['id'])) continue;
            $id = (string)$c['id'];
            $charIndexById[$id] = (int)$i;
            if (stripos((string)($c['name'] ?? ''), 'hero') !== false) $heroIds[$id] = true;
        }

        $instances = is_array($project['hitboxInstances'] ?? null) ? $project['hitboxInstances'] : [];
        $objects = is_array($project['hitboxObjects'] ?? null) ? $project['hitboxObjects'] : [];
        $objectById = [];
        foreach ($objects as $o) {
            if (is_array($o) && isset($o['id'])) $objectById[(string)$o['id']] = $o;
        }

        $enemySpawns = [];
        foreach ($playIdxs as $gi) {
            $screen = $screenData[$gi] ?? ($this->screenByIndex($project, $gi));
            $sid = is_array($screen) && isset($screen['id']) ? (string)$screen['id'] : '';
            $points = [];
            foreach ($instances as $inst) {
                if (!is_array($inst)) continue;
                if ((string)($inst['screenId'] ?? '') !== $sid) continue;
                $cid = isset($inst['characterId']) ? (string)$inst['characterId'] : '';
                if ($cid === '') {
                    $oid = $inst['objectId'] ?? ($inst['hitboxObjectId'] ?? '');
                    $o = $objectById[(string)$oid] ?? null;
                    if (is_array($o) && ($o['kind'] ?? '') === 'spawn' && isset($o['characterId'])) $cid = (string)$o['characterId'];
                }
                if ($cid === '' || isset($heroIds[$cid]) || !isset($charIndexById[$cid])) continue;
                $points[] = [(int)($inst['x'] ?? 0), (int)($inst['y'] ?? 0), $charIndexById[$cid]];
                if (count($points) >= $numInstances) break;
            }
            $enemySpawns[] = ['count' => count($points), 'points' => $points];
        }
        if (!$enemySpawns) $enemySpawns[] = ['count' => 0, 'points' => []];

        return [
            'charData' => $charData,
            'spriteChr' => $packed['spriteChr'],
            'usedCount' => $packed['usedCount'],
            'overflowCount' => $packed['overflowCount'],
            'truncated' => $packed['truncated'],
            'heroCharIdx' => $heroIdx,
            'heroFrameCount' => $heroFrames,
            'heroFound' => $heroFound,
            'numInstances' => $numInstances,
            'requestedInstances' => $requested,
            'enemySpawns' => $enemySpawns,
        ];
    }

    /**
     * Replica do packSpriteCHR() do build-rom.js.
     *
     * Regras mantidas para compatibilidade:
     * - tile 0 reservado no slot 0;
     * - cada frame usa no máximo um metatile 2x2;
     * - ordem TL/TR/BL/BR;
     * - overlay opcional com a mesma grade;
     * - limite de 256 tiles;
     * - CHR de sprites ocupa exatamente 4096 bytes.
     */
    private function packSpriteCHR(array $project, array $chars): array
    {
        $chr = is_array($project['chr'] ?? null) ? $project['chr'] : [];
        $metatiles = is_array($project['metatiles'] ?? null) ? $project['metatiles'] : [];
        $mapping = [0 => 0];
        $usedTiles = [0];
        $overflow = [];
        $truncated = [];
        $mtById = [];
        foreach ($metatiles as $mt) {
            if (is_array($mt) && isset($mt['id'])) $mtById[(string)$mt['id']] = $mt;
        }
        $corners = [
            ['dx'=>0,'dy'=>0], ['dx'=>8,'dy'=>0],
            ['dx'=>0,'dy'=>8], ['dx'=>8,'dy'=>8]
        ];

        $mapTile = function($tile) use (&$mapping, &$usedTiles, &$overflow): int {
            $orig = (int)($tile ?? 0);
            if ($orig < 0) $orig = 0;
            if (isset($mapping[$orig])) return $mapping[$orig];
            if (count($usedTiles) >= 256) {
                $overflow[$orig] = true;
                return 0;
            }
            $mapping[$orig] = count($usedTiles);
            $usedTiles[] = $orig;
            return $mapping[$orig];
        };

        $charData = [];
        foreach ($chars as $ci => $c) {
            if (!is_array($c)) $c = [];
            $anim = is_array($c['animations'][0] ?? null) ? $c['animations'][0] : ['name'=>'Idle','loop'=>true,'frames'=>[]];
            $framesIn = is_array($anim['frames'] ?? null) ? $anim['frames'] : [];
            $frames = [];
            foreach ($framesIn as $fi => $f) {
                if (!is_array($f)) $f = [];
                $mtId = (string)($f['metatileId'] ?? '');
                $mt = $mtById[$mtId] ?? null;
                $duration = max(1, min(255, (int)($f['duration'] ?? 8)));
                if (!is_array($mt) || !is_array($mt['tiles'] ?? null) || !isset($mt['w'], $mt['h'])) {
                    $frames[] = ['cells'=>[], 'duration'=>$duration, 'overlay'=>null];
                    continue;
                }
                $w = max(0, (int)$mt['w']);
                $h = max(0, (int)$mt['h']);
                if ($w > 2 || $h > 2) {
                    $truncated[] = (string)($c['name'] ?? "Character {$ci}") . ' / ' . (string)($anim['name'] ?? 'Idle') . ' / frame ' . ($fi + 1) . " ({$w}x{$h} → 2x2)";
                }
                $tiles = $mt['tiles'];
                $flips = is_array($mt['flips'] ?? null) ? $mt['flips'] : [];
                $cells = [];
                for ($ty=0; $ty<min(2,$h); $ty++) {
                    for ($tx=0; $tx<min(2,$w); $tx++) {
                        $idx = $ty*$w + $tx;
                        $raw = (int)($tiles[$idx] ?? 0);
                        $flip = (int)($flips[$idx] ?? 0);
                        $corner = $ty*2+$tx;
                        $cells[] = [
                            'tile' => $mapTile($raw),
                            'flip' => $flip,
                            'dx' => $corners[$corner]['dx'],
                            'dy' => $corners[$corner]['dy'],
                            'corner' => $corner
                        ];
                    }
                }

                $overlay = null;
                if (is_array($mt['overlay'] ?? null) && is_array($mt['overlay']['tiles'] ?? null) && count($mt['overlay']['tiles'])) {
                    $ov = $mt['overlay'];
                    $ovCells = [];
                    $ovFlips = is_array($ov['flips'] ?? null) ? $ov['flips'] : [];
                    for ($ty=0; $ty<min(2,$h); $ty++) {
                        for ($tx=0; $tx<min(2,$w); $tx++) {
                            $idx = $ty*$w + $tx;
                            $raw = $ov['tiles'][$idx] ?? null;
                            $corner = $ty*2+$tx;
                            if ($raw === null || (int)$raw < 0) continue;
                            $ovCells[] = [
                                'tile' => $mapTile((int)$raw),
                                'flip' => (int)($ovFlips[$idx] ?? 0),
                                'corner' => $corner
                            ];
                        }
                    }
                    $palIdx = isset($ov['palette']) ? (int)$ov['palette'] : 5;
                    $overlay = [
                        'cells' => $ovCells,
                        'dx' => (int)($ov['dx'] ?? 0),
                        'dy' => (int)($ov['dy'] ?? 0),
                        'palAttr' => max(0, min(3, $palIdx - 4))
                    ];
                }
                $frames[] = ['cells'=>$cells, 'duration'=>$duration, 'overlay'=>$overlay];
            }
            if (!$frames) $frames[] = ['cells'=>[], 'duration'=>8, 'overlay'=>null];
            $charData[] = [
                'id' => $c['id'] ?? null,
                'name' => $c['name'] ?? "Character {$ci}",
                'frames' => $frames
            ];
        }

        $spriteChr = array_fill(0, 4096, 0);
        foreach ($usedTiles as $i => $srcIdx) {
            $srcIdx = ((int)$srcIdx) % 512;
            $srcOff = $srcIdx * 16;
            $dstOff = $i * 16;
            for ($j=0; $j<16; $j++) {
                $spriteChr[$dstOff+$j] = (int)($chr[$srcOff+$j] ?? 0) & 0xFF;
            }
        }

        return [
            'spriteChr' => $spriteChr,
            'charData' => $charData,
            'usedCount' => count($usedTiles),
            'overflowCount' => count($overflow),
            'truncated' => $truncated,
        ];
    }

    private function screenByIndex(array $project, int $index): array
    {
        $screens = $this->collectGameScreens($project);
        return is_array($screens[$index] ?? null) ? $screens[$index] : [];
    }


    private function findRoleIndex(array $screens, string $role, int $fallback): int
    {
        foreach ($screens as $i => $screen) {
            if (($screen['role'] ?? null) === $role) return $i;
        }
        return $fallback;
    }

    /**
     * Replica apenas da resolução de telas usada pelo gerador atual.
     * O empacotamento CHR continua no frontend nesta fase; o NGC precisa
     * somente dos índices das telas para gerar o RESET corretamente.
     */
    private function collectGameScreens(array $project): array
    {
        $screens = [];
        $seen = [];
        $bgs = is_array($project['backgrounds'] ?? null) ? $project['backgrounds'] : [];
        $splashes = is_array($project['splashScreens'] ?? null) ? $project['splashScreens'] : [];
        $bgById = [];
        $splashById = [];
        foreach ($bgs as $bg) if (is_array($bg) && isset($bg['id'])) $bgById[(string)$bg['id']] = $bg;
        foreach ($splashes as $sp) if (is_array($sp) && isset($sp['id'])) $splashById[(string)$sp['id']] = $sp;

        $phases = is_array($project['phases'] ?? null) ? $project['phases'] : [];
        foreach ($phases as $ph) {
            if (!is_array($ph)) continue;
            $lm = $ph['levelMap'] ?? null;
            if (!is_array($lm) || !is_array($lm['cells'] ?? null)) continue;
            $cols = max(1, (int)($lm['cols'] ?? 1));
            $rows = max(1, (int)($lm['rows'] ?? 1));
            for ($y = 0; $y < $rows; $y++) {
                for ($x = 0; $x < $cols; $x++) {
                    $cell = $lm['cells'][$x . ',' . $y] ?? null;
                    if (!is_array($cell) || empty($cell['bgId'])) continue;
                    $id = (string)$cell['bgId'];
                    if (isset($seen[$id])) continue;
                    $asset = (($cell['type'] ?? '') === 'splash')
                        ? ($splashById[$id] ?? null)
                        : ($bgById[$id] ?? null);
                    if (!is_array($asset)) continue;
                    $seen[$id] = true;
                    $isSplash = (($cell['type'] ?? '') === 'splash');
                    $screens[] = [
                        'id' => $asset['id'],
                        'name' => $asset['name'] ?? $id,
                        'type' => $isSplash ? 'splash' : 'background',
                        'phaseId' => $ph['id'] ?? null,
                        'phaseName' => $ph['name'] ?? null,
                        'role' => $isSplash ? 'splash' : 'play',
                    ];
                }
            }
        }

        foreach ($splashes as $sp) {
            if (!is_array($sp) || !isset($sp['id'])) continue;
            $id = (string)$sp['id'];
            if (isset($seen[$id])) continue;
            $seen[$id] = true;
            $screens[] = [
                'id' => $sp['id'],
                'name' => $sp['name'] ?? $id,
                'type' => 'splash',
                'phaseId' => null,
                'phaseName' => null,
                'role' => 'gameover',
            ];
        }

        if (!$screens) {
            $fallback = $splashes ?: $bgs;
            foreach ($fallback as $i => $asset) {
                if (!is_array($asset) || !isset($asset['id'])) continue;
                $screens[] = [
                    'id' => $asset['id'],
                    'name' => $asset['name'] ?? $asset['id'],
                    'type' => $splashes ? 'splash' : 'background',
                    'phaseId' => null,
                    'phaseName' => null,
                    'role' => $i === 0 ? 'splash' : 'play',
                ];
            }
        }

        return $screens;
    }

    private function resolveMusic(array $project, string $musicId): ?array
    {
        if ($musicId === '' || $musicId === 'none') return null;
        $sounds = $project['sounds'] ?? null;
        if (!is_array($sounds)) return null;

        if (($sounds['version'] ?? null) === 3 && is_array($sounds['items'] ?? null)) {
            foreach ($sounds['items'] as $item) {
                if (is_array($item) && ($item['id'] ?? null) === $musicId && is_array($item['channels'] ?? null) && count($item['channels'])) {
                    return $item;
                }
            }
        }

        if (($sounds['version'] ?? null) === 2 && is_array($sounds['channels'] ?? null)) {
            return [
                'id' => 'song_legacy',
                'name' => 'Musica 1',
                'loop' => $sounds['loop'] ?? true,
                'baseFrames' => $sounds['baseFrames'] ?? 30,
                'channels' => $sounds['channels'],
            ];
        }

        return null;
    }
}
