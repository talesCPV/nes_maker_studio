<?php

require_once __DIR__ . '/ProjectParser.php';
require_once __DIR__ . '/AsmBuilder.php';

final class NGC
{
    private array $templates;

    public function __construct(array $templates)
    {
        $this->templates = $templates;
    }

    /**
     * NGC v0.14 - migração incremental dos subsistemas do gerador.
     *
     * Nesta etapa o backend já é responsável por gerar os blocos HEADER e
     * VECTORS. Os demais blocos continuam no gerador legado do frontend.
     * Isso permite migrar incrementalmente sem alterar o comportamento atual.
     */
    public function build(array $request): array
    {
        $parser = new ProjectParser();
        $context = $parser->parse($request);
        $builder = new AsmBuilder();

        $header = $this->renderTemplate('header', $context);
        $vectors = $this->renderTemplate('vectors', $context);
        $zeropage = $this->renderTemplate('zeropage', $context);
        $nmi = $this->renderTemplate('nmi', $context);
        $reset = $this->renderTemplate('reset', $context);
        $input = $this->renderTemplate('input', $context);
        $mainLoop = $this->renderTemplate('main_loop', $context);
        $collision = $this->renderTemplate('collision', $context);
        $player = $this->renderTemplate('player', $context);
        $scroll = $this->renderTemplate('scroll', $context);
        $background = $this->renderTemplate('background', $context);
        $backgroundTables = $this->renderTemplate('background_tables', $context);
        $backgroundData = $this->renderTemplate('background_data', $context);
        $spritePlayer = $this->renderTemplate('sprite_player', $context);
        $spriteEntities = $this->renderTemplate('sprite_entities', $context);
        $spriteData = $this->renderTemplate('sprite_data', $context);
        $spriteChr = $this->renderTemplate('sprite_chr', $context);
        $music = $this->renderTemplate('music', $context);

        $builder->add($header);
        $builder->add($vectors);
        $builder->add($zeropage);
        $builder->add($nmi);
        $builder->add($reset);
        $builder->add($input);
        $builder->add($mainLoop);
        $builder->add($collision);
        $builder->add($player);
        $builder->add($scroll);
        $builder->add($background);
        $builder->add($backgroundTables);
        $builder->add($backgroundData);
        $builder->add($spritePlayer);
        $builder->add($spriteEntities);
        $builder->add($spriteData);
        $builder->add($spriteChr);
        $builder->add($music);

        return [
            'ok' => true,
            'ready' => true,
            'partial' => true,
            'compiler' => 'NGC',
            'version' => '0.16.0',
            'buildMode' => $context['buildMode'],
            'projectName' => $context['project']['name'] ?? 'meu-jogo',
            'blocks' => [
                'header' => $header,
                'vectors' => $vectors,
                'zeropage' => $zeropage,
                'nmi' => $nmi,
                'reset' => $reset,
                'input' => $input,
                'main_loop' => $mainLoop,
                'collision' => $collision,
                'player' => $player,
                'scroll' => $scroll,
                'background' => $background,
                'background_tables' => $backgroundTables,
                'background_data' => $backgroundData,
                'sprite_player' => $spritePlayer,
                'sprite_entities' => $spriteEntities,
                'sprite_data' => $spriteData,
                'sprite_chr' => $spriteChr,
                'music' => $music,
            ],
            'asm' => $builder->build(),
            'migrated' => ['header', 'vectors', 'zeropage', 'nmi', 'reset', 'input', 'main_loop', 'collision', 'player', 'scroll', 'background', 'background_tables', 'background_data', 'sprite_player', 'sprite_entities', 'sprite_data', 'sprite_chr', 'music'],
        ];
    }

    private function renderTemplate(string $name, array $context): string
    {
        if (!isset($this->templates[$name]) || !is_callable($this->templates[$name])) {
            throw new RuntimeException("Template NGC inválido: {$name}");
        }

        return trim((string) call_user_func($this->templates[$name], $context));
    }
}
