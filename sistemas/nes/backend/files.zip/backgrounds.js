// BACKGROUND MODULE v0.9.7 - Ferramenta Warp Separada no Menu
const BG = (() => {
  let nametable = new Array(32 * 30).fill(0);
  let attributes = new Array(64).fill(0);
  let collisionMap = new Array(32 * 30).fill(0);
  // Camada 8 (compressão por metatile): 1 célula por metatile 2x2 (16 col x 15
  // lin = 240 células, cobre a tela de 32x30 tiles) - guarda o ID do metatile
  // carimbado ali, ou null se essa célula não corresponde a UM metatile só
  // (apagada com o borrador de tile cru, editada fora do fluxo de carimbo,
  // ou tela salva antes dessa funcionalidade existir). O backend só consegue
  // comprimir a tela se TODAS as 240 células estiverem preenchidas - ver
  // hasCleanMetatileGrid().
  let metatileGrid = new Array(16 * 15).fill(null);
  let currentEntryId = null;
  let currentEntryName = '';
  let currentEntryType = null; // 'bg' | 'splash' | null (tela nova, ainda não classificada)
  let selectedMetatile = null;
  let activePalette = 0;
  let selectedCollisionType = 1;
  let isDrawing = false;
  let textMode = false;
  let textCursor = { x: 0, y: 0 };
  let textPalette = 0;
  let textOffsetMode = 'smb'; // 'smb' (0-9,A-Z sequencial) ou 'ascii' (código ASCII direto)
  let bgCanvas, bgCtx;
  let currentTool = 'paint';
  // Zoom visual do canvas (resolução interna continua 512×480)
  let canvasZoom = 1;
  const CANVAS_ZOOM_MIN = 0.5;
  const CANVAS_ZOOM_MAX = 2.5;
  const CANVAS_ZOOM_STEP = 0.25;
  let selectedTextIdx = null;
  let movingTextMode = false;
  let duplicatingTextMode = false;
  // Cache do que existia no nametable/atributos ANTES de cada camada de texto ser escrita,
  // guardado por layer.id. Só em memória durante a edição - nunca vai pro .nms porque fica
  // fora do objeto da camada (que é o que de fato é serializado ao salvar).
  let textUnderCache = {};
  let textLayers = [];
  let hitboxInstances = []; // [{x,y,hitboxObjectId}] - por-tela, sparse (só posições com dano/warp)
  let currentChrPage = 1; // pg ímpar: pg0 de cada banco é reservada para sprites, background só usa pg1, pg3...
  // Rascunho em memória por página do CHR: evita misturar metatiles de páginas diferentes na
  // mesma tela quando o usuário troca de página no meio do desenho. Cada página guarda seu
  // próprio nametable/atributos/colisão/textos em progresso; trocar de página salva o estado
  // atual na página de origem e restaura (ou cria em branco) o estado da página de destino.
  let pageDrafts = {};
  let globalEventsAttached = false;

  function isValidForBG(mt) {
    return mt && mt.w >= 2 && mt.h >= 2 && mt.w % 2 === 0 && mt.h % 2 === 0;
  }

  function formatTileAddr(tileIdx) {
    const t = tileIdx || 0;
    const page = t >= 256 ? 1 : 0;
    const rel = t % 256;
    return `PT${page}:$${rel.toString(16).padStart(2, "0").toUpperCase()}`;
  }

  function ensureMetatileCollisions(mt) {
    if (!mt) return;
    const size = (mt.w || 2) * (mt.h || 2);
    if (!mt.collisions || !Array.isArray(mt.collisions) || mt.collisions.length !== size) {
      const defaultCol = mt.collisionType !== undefined ? mt.collisionType : 1;
      mt.collisions = new Array(size).fill(defaultCol);
    }
  }

  function buildHTML(){
    const root = document.getElementById('mod-bg');
    if(!root) return;
    root.innerHTML = `
      <div style="display:flex;flex-direction:column;height:100%;background:#1e1e1e;overflow:hidden">
        <div id="bgToolsToolbar" style="display:flex;gap:6px;align-items:center;padding:6px 10px;background:#252526;border-bottom:1px solid #333;flex-wrap:nowrap;overflow-x:auto;overflow-y:hidden;white-space:nowrap">
          <select id="bgSelect" title="Selecionar background/splash" style="background:#111;color:#fff;border:1px solid #444;border-radius:6px;padding:4px 8px;font-size:11px;min-width:140px;height:36px;box-sizing:border-box"></select>
          <button type="button" class="icon-btn" onclick="BG.newCanvas()" title="Novo canvas">✨</button>
          <button type="button" class="icon-btn" onclick="BG.saveCurrentEntry()" title="Salvar">💾</button>
          <button type="button" class="icon-btn" onclick="BG.saveAsClone()" title="Salvar como… (clonar tela)">📄</button>
          <button type="button" class="icon-btn" onclick="BG.renameCurrentEntry()" title="Renomear">✏️</button>
          <button type="button" class="icon-btn" onclick="BG.deleteCurrentEntry()" title="Deletar entrada atual" style="background:#5a1a1a;border-color:#7d2525">🗑</button>
          <span style="width:1px;height:24px;background:#444;margin:0 2px"></span>
          <span style="font-size:10px;color:#888;margin-right:2px">TOOLS</span>
          <button type="button" class="icon-btn tool-btn active" data-bg-tool="paint" onclick="BG.setTool('paint')" title="Pintar">🎨</button>
          <button type="button" class="icon-btn tool-btn" data-bg-tool="flood" onclick="BG.setTool('flood')" title="Flood Fill">🌊</button>
          <button type="button" class="icon-btn tool-btn" data-bg-tool="attr" onclick="BG.setTool('attr')" title="Pincel de Paleta">🖌</button>
          <button type="button" class="icon-btn tool-btn" data-bg-tool="hitbox" onclick="BG.setTool('hitbox')" title="Hitbox Manual">🛡</button>
          <button type="button" class="icon-btn tool-btn" data-bg-tool="assign" onclick="BG.setTool('assign')" title="Atribuir objeto (Dano/Warp)">🎯</button>
          <button type="button" class="icon-btn tool-btn" data-bg-tool="erase" onclick="BG.setTool('erase')" title="Borracha">🧽</button>
          <button type="button" class="icon-btn tool-btn" data-bg-tool="text" onclick="BG.setTool('text')" title="Texto">🔤</button>
          <button type="button" class="icon-btn tool-btn" data-bg-tool="fill" onclick="BG.setTool('fill')" title="Auto-Fill">🪣</button>
          <span style="width:1px;height:24px;background:#444;margin:0 2px"></span>
          <button type="button" class="icon-btn" onclick="BG.zoomOut()" title="Diminuir zoom do grid">➖</button>
          <span id="bgZoomLabel" style="font-size:10px;color:#888;min-width:36px;text-align:center">100%</span>
          <button type="button" class="icon-btn" onclick="BG.zoomIn()" title="Aumentar zoom do grid">➕</button>
          <span style="width:1px;height:24px;background:#444;margin:0 2px"></span>
          <span id="bgModeLabel" style="font-size:10px;color:#4ec9b0;background:#111;border:1px solid #333;border-radius:3px;padding:2px 6px;flex-shrink:0">Modo: Pintura</span>
          <span id="bgHelpText" style="font-size:10px;color:#888;white-space:normal;max-width:min(420px,35vw);line-height:1.3">Pintura livre. Alt+clique clona. Shift+clique apaga.</span>
        </div>

        <div style="display:flex;flex:1;overflow:hidden;min-height:0">
          <!-- Área principal: grid à esquerda + painéis de ferramentas/metatiles -->
          <div id="bgMainRow" style="flex:1;min-width:0;display:flex;flex-wrap:wrap;overflow:auto;background:#111;align-content:flex-start">
            <div id="bgGridPane" style="flex:1 1 auto;padding:12px;overflow:auto;display:flex;flex-direction:column;align-items:center;gap:8px;box-sizing:border-box">
              <div style="display:flex;gap:12px;align-items:center;font-size:11px;color:#888;flex-wrap:wrap">
                <label style="display:flex;align-items:center;gap:4px;cursor:pointer"><input type="checkbox" id="chkShowHitbox" checked> Hitbox</label>
                <label style="display:flex;align-items:center;gap:4px">Tipo:
                  <select id="bgEntryTypeSelect" title="Tipo da tela (Background ou Splash)" style="background:#111;color:#fff;border:1px solid #444;border-radius:4px;padding:2px 4px;font-size:11px">
                    <option value="bg">Background</option>
                    <option value="splash">Splash</option>
                  </select>
                </label>
                <label style="display:flex;align-items:center;gap:4px">Grid:
                  <select id="bgGridSelect" style="background:#111;color:#fff;border:1px solid #444;border-radius:4px;padding:2px 4px;font-size:11px">
                    <option value="none">Sem grid</option>
                    <option value="1x1">1x1</option>
                    <option value="2x2" selected>2x2</option>
                    <option value="4x4">4x4</option>
                  </select>
                </label>
                <span id="hoverPos" style="color:#4ec9b0;background:#000;padding:2px 6px;border-radius:3px;border:1px solid #333">x:0 y:0</span>
              </div>
              <canvas id="bgCanvas" width="512" height="480" style="border:2px solid #665500;background:#000;image-rendering:pixelated;cursor:crosshair;display:block"></canvas>
            </div>

            <div id="bgSidePane" style="flex:1 1 280px;width:320px;min-width:280px;max-width:360px;background:#181818;border-left:1px solid #333;padding:12px;overflow:auto;display:flex;flex-direction:column;gap:12px;box-sizing:border-box">
              <div id="bgHitboxPanel" style="display:none;background:#2a0808;border:1px solid #881111;border-radius:6px;padding:8px">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                  <h4 style="font-size:10px;color:#ff6666;margin:0">HITBOX MANUAL</h4>
                  <label style="font-size:10px;color:#ffcc00;display:flex;align-items:center;gap:3px;cursor:pointer"><input type="checkbox" id="chkHitboxFlood"> 🪣 Flood</label>
                </div>
                <div style="display:flex;gap:4px;flex-wrap:wrap">
                  <button class="btn-tool collision-btn" data-col-type="0" onclick="BG.setCollisionType(0)" style="font-size:10px">⬜ 0: Livre</button>
                  <button class="btn-tool collision-btn active" data-col-type="1" onclick="BG.setCollisionType(1)" style="font-size:10px;background:#c0392b;color:#fff">🟥 1: Sólido</button>
                  <button class="btn-tool collision-btn" data-col-type="2" onclick="BG.setCollisionType(2)" style="font-size:10px;background:#27ae60;color:#fff">🟩 2: Plataforma</button>
                  <button class="btn-tool collision-btn" data-col-type="3" onclick="BG.setCollisionType(3)" style="font-size:10px;background:#8e44ad;color:#fff">🟪 3: Dano</button>
                  <button class="btn-tool collision-btn" data-col-type="4" onclick="BG.setCollisionType(4)" style="font-size:10px;background:#d35400;color:#fff">🚪 4: Warp</button>
                </div>
              </div>

              <div id="bgFillPanel" style="display:none;background:#1a1a00;border:1px solid #665500;border-radius:6px;padding:8px">
                <h4 style="font-size:10px;color:#ffcc00;margin-bottom:6px">AÇÕES DE PREENCHIMENTO</h4>
                <div style="display:flex;gap:4px;flex-wrap:wrap">
                  <button class="btn-tool" onclick="BG.fillAllEmpty()" style="font-size:10px">⬜ Só Vazios</button>
                  <button class="btn-tool" onclick="BG.fillEntireScreen()" style="font-size:10px;background:#ffcc00;color:#000">🌟 Tela toda</button>
                  <button class="btn-tool" onclick="BG.applyAttrToAll()" style="font-size:10px;background:#2980b9;color:#fff">🎨 Paleta Global</button>
                  <button class="btn-tool" style="font-size:10px;background:#8e44ad;color:#fff" title="Clique no canvas: troca a região conectada pelo metatile selecionado">🌊 Flood (clique)</button>
                  <button class="btn-tool" onclick="BG.clearBackground()" style="font-size:10px;background:#c0392b;color:#fff">🧹 Limpar</button>
                  <button class="btn-tool" onclick="BG.migrateLegacyScreen()" style="font-size:10px;background:#16a085;color:#fff" title="TEMPORÁRIO: reconhece os metatiles usados no nametable/colisão crus desta tela e preenche a grade nova. Remover depois que todas as telas antigas forem migradas.">🔄 Migrar tela legada</button>
                </div>
                <div style="font-size:9px;color:#888;margin-top:6px;line-height:1.3">Flood: selecione o metatile de destino e clique numa região no canvas — todos os blocos conectados iguais ao ponto clicado são trocados.</div>
              </div>

              <div id="bgTextPanel" style="display:none;background:#1a1a00;border:1px solid #665500;border-radius:6px;padding:8px">
                <h4 style="font-size:10px;color:#ffcc00;margin-bottom:6px">🔤 TEXTO - CLIQUE NO CANVAS PARA POSICIONAR</h4>
                <div style="display:flex;gap:6px;align-items:center;margin-bottom:6px">
                  <label style="font-size:10px;color:#888">Offset:</label>
                  <select id="bgTextOffsetSelect" style="background:#000;color:#ffcc00;border:1px solid #665500;border-radius:4px;padding:3px;font-size:10px" onchange="BG.setTextOffsetMode(this.value)">
                    <option value="smb">SMB (0-9, A-Z sequencial)</option>
                    <option value="ascii">ASCII (código direto)</option>
                  </select>
                </div>
                <div style="display:flex;gap:4px;margin:4px 0">
                  <input id="bgTextInput" type="text" placeholder="Digite texto + Enter" style="flex:1;background:#000;color:#ffcc00;border:1px solid #665500;border-radius:4px;padding:6px;font-size:12px;font-family:monospace">
                  <button class="btn-tool" onclick="BG.insertText()" style="background:#ffcc00;color:#000">Inserir</button>
                </div>
                <div style="display:flex;gap:6px;align-items:center;margin-top:6px;flex-wrap:wrap">
                  <label style="font-size:10px;color:#888">Paleta:</label>
                  <div id="bgTextPalettes" style="display:flex;gap:4px"></div>
                  <span style="font-size:10px;color:#666">Cursor: <b id="bgCursorPos" style="color:#ffcc00">0,0</b></span>
                  <button class="btn-tool" onclick="BG.clearTextSelection()" style="font-size:9px;margin-left:auto">✖ Deselecionar</button>
                </div>
              </div>

              <div style="background:#111;border:1px solid #333;border-radius:6px;padding:10px">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                  <h4 style="font-size:11px;color:#4ec9b0;margin:0">NAMETABLES</h4>
                  <div style="display:flex;align-items:center;gap:4px"><span style="font-size:10px;color:#888">Fase:</span><select id="bgChrPageSelect" title="Fase → página BG do CHR" style="background:#000;color:#ffcc00;border:1px solid #665500;border-radius:3px;font-size:10px;padding:2px 6px;min-width:120px"></select></div>
                </div>
                <div id="metatilePalette" style="display:flex;flex-wrap:wrap;gap:6px;max-height:180px;overflow:auto;padding-right:4px"></div>
              </div>

              <div style="background:#111;border:1px solid #333;border-radius:6px;padding:10px;display:flex;flex-direction:column;gap:8px">
                <div style="display:flex;flex-direction:column;align-items:center;gap:4px">
                  <div id="selectedInfo" style="font-size:10px;color:#aaa;text-align:center">Nenhum</div>
                  <canvas id="selectedPreview" width="80" height="80" style="border:1px solid #ffcc00;background:#000;image-rendering:pixelated;display:block;cursor:pointer" title="Clique no sub-tile para alternar colisão!"></canvas>
                </div>
                <div style="border-top:1px solid #222;padding-top:6px;display:flex;flex-direction:column;gap:4px"><div style="display:flex;justify-content:space-between;align-items:center"><label style="font-size:10px;color:#ffcc00">🛡 Hitbox por Tile:</label><button class="btn-tool" onclick="BG.setAllSubTilesCollision()" style="font-size:9px;padding:1px 4px">Setar Todos</button></div><div style="display:flex;gap:4px"><select id="mtSubTileColSelect" style="flex:1;background:#000;color:#fff;border:1px solid #444;border-radius:3px;padding:3px;font-size:10px"><option value="0">⬜ 0: Ar/Livre</option><option value="1">🟥 1: Sólido</option><option value="2">🟩 2: Plataforma</option><option value="3">🟪 3: Dano/Espinho</option><option value="4">🚪 4: Warp</option></select><button class="btn-tool" onclick="BG.applyMetatileHitboxToCanvas()" style="font-size:10px;background:#27ae60;color:#fff">⚡ Recalcular</button></div></div>
                <div id="mtDefaultObjWrap" style="border-top:1px solid #222;padding-top:6px;display:none;flex-direction:column;gap:4px">
                  <label style="font-size:10px;color:#ffcc00">🎯 Objeto padrão (Dano/Warp):</label>
                  <select id="mtDefaultObjSelect" onchange="BG.setMetatileDefaultObject(this.value)" style="background:#000;color:#fff;border:1px solid #444;border-radius:3px;padding:3px;font-size:10px"></select>
                  <div style="font-size:9px;color:#666;line-height:1.3">Usado quando este metatile é carimbado na tela. Cada carimbo pode depois trocar pra outro objeto individualmente.</div>
                </div>
              </div>

              <div id="bgTextLayersPanel" style="display:none;background:#111;border:1px solid #665500;border-radius:6px;padding:10px;flex:1;min-height:120px;flex-direction:column">
                <h4 style="font-size:11px;color:#ffcc00;margin-bottom:8px">📝 CAMADAS DE TEXTO</h4>
                <div id="bgTextLayers" style="display:flex;flex-direction:column;gap:6px;flex:1;overflow:auto;max-height:220px"></div>
              </div>

              <div style="font-size:11px;color:#888;background:#111;border:1px solid #333;padding:8px;border-radius:4px">
                Tiles: <b id="bgStats" style="color:#fff">0/960</b><br>
                Hitbox: <b id="solidStats" style="color:#ff6666">0</b><br>
                Textos: <b id="textCount" style="color:#fff">0</b>
              </div>
            </div>
          </div>
        </div>

        <div id="bgPalettePanel" class="chr-palette-panel collapsed">
          <div class="chr-palette-bar">
            <button type="button" id="bgPaletteToggle" class="icon-btn" title="Expandir / recolher paletas" onclick="BG.togglePalettePanel()">▸</button>
            <span class="chr-palette-bar-title">Paletas BG</span>
            <div id="bgPaletteCompact" class="chr-palette-compact" title="Slots de atributo BG (0–3)"></div>
            <span id="bgPaletteBarHint" class="chr-palette-bar-hint">clique ▸ para expandir banco e slots</span>
          </div>
          <div class="chr-palette-body">
            <!-- 1) Atributo / slots PPU BG -->
            <div>
              <h4 style="font-size:11px;color:#4ec9b0;margin:0 0 8px">PALETAS PPU (BG 0–3)</h4>
              <div id="attrPaletteSelect" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"></div>
              <div style="display:flex;gap:6px;align-items:center;margin-top:8px;flex-wrap:wrap">
                <span style="font-size:10px;color:#888">Cor ativa do slot:</span>
                <div id="bgQuickColors" style="display:flex;gap:4px"></div>
                <span style="font-size:9px;color:#666">clique num quadrado da sub-paleta e depois na master NES</span>
              </div>
            </div>
            <!-- 2) Master NES -->
            <div>
              <h4 style="font-size:11px;color:#4ec9b0;margin:0 0 8px">PALETA MASTER NES (clique pra trocar cor do slot)</h4>
              <div id="bgMasterPaletteGrid" style="display:flex;flex-direction:column;gap:2px;background:#111;padding:8px;border-radius:6px;border:1px solid #333;width:fit-content"></div>
            </div>
            <!-- 3) Banco + ativos BG -->
            <div style="border:1px solid #333;border-radius:6px;background:#1a1a1a;padding:10px">
              <h4 style="font-size:11px;color:#c39bd3;margin:0 0 8px">BANCO DE PALETAS</h4>
              <div style="display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap">
                <div style="flex:1;min-width:220px">
                  <div id="bgPaletteBankList" data-palette-bank-list style="max-height:140px;overflow:auto;border:1px solid #333;border-radius:4px;background:#0a0a0a;margin-bottom:6px"></div>
                  <div style="display:flex;gap:4px;flex-wrap:wrap">
                    <button type="button" class="btn-tool" onclick="BG.paletteBankAdd()" style="font-size:9px;flex:1" title="Nova entrada no banco">+ Nova</button>
                    <button type="button" class="btn-tool" onclick="BG.paletteBankApply()" style="font-size:9px;flex:1;background:#007acc;color:#fff" title="Aplicar no slot BG ativo">→ Ativo</button>
                    <button type="button" class="btn-tool" onclick="BG.paletteBankRename()" style="font-size:9px">✎</button>
                    <button type="button" class="btn-tool" onclick="BG.paletteBankDelete()" style="font-size:9px;background:#c0392b;color:#fff">✕</button>
                  </div>
                </div>
                <div style="min-width:200px;flex:0 0 220px">
                  <div style="font-size:9px;color:#666;margin-bottom:2px">Ativas BG</div>
                  <div id="bgPaletteActiveBG"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    bgCanvas = document.getElementById('bgCanvas');
    bgCtx = bgCanvas ? bgCanvas.getContext('2d') : null;
    applyCanvasZoom();
    attachEvents();
    initChrPageSelect();
    updateBGSelect();
    refreshMetatileList();
    refreshBgPalettePanel();
    updateTextPaletteUI();
    render();
  }

  function applyCanvasZoom(){
    if(!bgCanvas) bgCanvas = document.getElementById('bgCanvas');
    if(!bgCanvas) return;
    const w = Math.round(512 * canvasZoom);
    const h = Math.round(480 * canvasZoom);
    bgCanvas.style.width = w + 'px';
    bgCanvas.style.height = h + 'px';
    // min-width da área do grid = tamanho visual do canvas + padding lateral (12+12)
    const gridPane = document.getElementById('bgGridPane');
    if(gridPane){
      gridPane.style.minWidth = (w + 24) + 'px';
    }
    const lbl = document.getElementById('bgZoomLabel');
    if(lbl) lbl.textContent = Math.round(canvasZoom * 100) + '%';
  }

  function zoomIn(){
    canvasZoom = Math.min(CANVAS_ZOOM_MAX, Math.round((canvasZoom + CANVAS_ZOOM_STEP) * 100) / 100);
    applyCanvasZoom();
  }

  function zoomOut(){
    canvasZoom = Math.max(CANVAS_ZOOM_MIN, Math.round((canvasZoom - CANVAS_ZOOM_STEP) * 100) / 100);
    applyCanvasZoom();
  }

  function setTool(t) {
    currentTool = t;
    document.querySelectorAll('#mod-bg .tool-btn[data-bg-tool]').forEach(b => {
      const on = b.getAttribute('data-bg-tool') === t;
      b.classList.toggle('active', on);
      if(on){ b.style.background = '#007acc'; b.style.borderColor = '#007acc'; }
      else { b.style.background = ''; b.style.borderColor = ''; }
    });
    const fillPanel = document.getElementById('bgFillPanel');
    const textPanel = document.getElementById('bgTextPanel');
    const hitboxPanel = document.getElementById('bgHitboxPanel');
    const textLayersPanel = document.getElementById('bgTextLayersPanel');
    if(fillPanel) fillPanel.style.display = (t === 'fill') ? 'block' : 'none';
    if(textPanel) textPanel.style.display = (t === 'text') ? 'block' : 'none';
    if(hitboxPanel) hitboxPanel.style.display = (t === 'hitbox') ? 'block' : 'none';
    if(textLayersPanel){
      textLayersPanel.style.display = (t === 'text') ? 'flex' : 'none';
    }
    const label = document.getElementById('bgModeLabel');
    const help = document.getElementById('bgHelpText');
    textMode = (t === 'text');
    if(t === 'flood') { label.textContent = 'Modo: Flood Fill'; help.textContent = 'Preenche área contígua com o metatile selecionado.'; }
    else if(t === 'attr') { label.textContent = 'Modo: Pincel de Atributo'; help.textContent = 'Pinta a paleta mantendo as estampas.'; }
    else if(t === 'hitbox') { label.textContent = 'Modo: Hitbox Manual'; help.textContent = 'Pinta colisão individualmente (inclui Warp). Shift+clique apaga.'; }
    else if(t === 'assign') { label.textContent = 'Modo: Atribuir Objeto'; help.textContent = 'Clique num tile de Dano/Warp - todos os vizinhos conectados do mesmo tipo são atribuídos juntos.'; }
    else if(t === 'fill') { label.textContent = 'Modo: Auto-Fill'; help.textContent = 'Botões = massa. Clique no canvas = flood: troca região conectada pelo metatile selecionado.'; }
    else if(t === 'erase') { label.textContent = 'Modo: Borracha'; help.textContent = 'Clique (ou arraste) num tile para apagá-lo, tile por tile.'; }
    else if(t === 'text') { 
      label.textContent = 'Modo: Texto ASCII - CLIQUE NO CANVAS'; 
      help.textContent = 'CLIQUE no canvas para posicionar o cursor. Digite e Insira. Camadas de texto aparecem no painel lateral.';
      updateCursorPos();
    }
    else { label.textContent = 'Modo: Pintura Metatile'; help.textContent = 'Pinta Metatile + Atributo + Hitbox sub-tile. Alt+clique clona. Shift+clique apaga.'; }
    render();
  }

  function setCollisionType(type) {
    selectedCollisionType = parseInt(type);
    document.querySelectorAll('.collision-btn').forEach(b => b.classList.remove('active'));
    document.querySelector(`[data-col-type="${type}"]`)?.classList.add('active');
  }

  function updateCursorPos(){
    const el = document.getElementById('bgCursorPos');
    if(el) el.textContent = `${textCursor.x},${textCursor.y}`;
  }

  function clearTextSelection(){
    selectedTextIdx = null;
    movingTextMode = false;
    updateTextLayersUI();
    render();
  }

  function handlePreviewClick(e) {
    if(!selectedMetatile) return;
    ensureMetatileCollisions(selectedMetatile);
    const canv = document.getElementById('selectedPreview');
    const rect = canv.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    const w = selectedMetatile.w || 2, h = selectedMetatile.h || 2;
    const tileW = 80 / w, tileH = 80 / h;
    const subX = Math.floor(mx / tileW), subY = Math.floor(my / tileH);
    if(subX < 0 || subX >= w || subY < 0 || subY >= h) return;
    const subIdx = subY * w + subX;
    const curr = selectedMetatile.collisions[subIdx] || 0;
    // Camada 8 (compressão por metatile): a tabela comprimida guarda só 1
    // byte de colisão por metatile (máscara de quadrante + 1 ÚNICO tipo) -
    // misturar 2 tipos diferentes dentro do mesmo metatile não é
    // representável nesse formato. Uma vez que outro quadrante já
    // estabeleceu um tipo, os demais só alternam entre livre (0) e ESSE
    // MESMO tipo - pra usar outro tipo, zera os quadrantes desse metatile
    // primeiro (Setar Todos com 0, ou apagar quadrante a quadrante).
    const established = selectedMetatile.collisions.find((c, i) => i !== subIdx && (c || 0) > 0) || 0;
    let nextCol = (curr + 1) % 4;
    if(established){
      while(nextCol !== 0 && nextCol !== established) nextCol = (nextCol + 1) % 4;
    }
    selectedMetatile.collisions[subIdx] = nextCol;
    updateSelectedInfo();
  }

  function setAllSubTilesCollision() {
    if(!selectedMetatile) return;
    ensureMetatileCollisions(selectedMetatile);
    const typeVal = parseInt(document.getElementById('mtSubTileColSelect')?.value || 0);
    selectedMetatile.collisions.fill(typeVal);
    updateSelectedInfo();
  }

  function applyMetatileHitboxToCanvas() {
    if(!selectedMetatile) return;
    ensureMetatileCollisions(selectedMetatile);
    const mt = selectedMetatile;
    let count = 0;
    for(let y=0; y<30; y++) {
      for(let x=0; x<32; x++) {
        const snapX = Math.floor(x / mt.w) * mt.w;
        const snapY = Math.floor(y / mt.h) * mt.h;
        let match = true;
        for(let dy=0; dy<mt.h; dy++){
          for(let dx=0; dx<mt.w; dx++){
            const nx = snapX + dx, ny = snapY + dy;
            if(nx < 32 && ny < 30) {
              if(nametable[ny * 32 + nx] !== mt.tiles[dy * mt.w + dx]) {
                match = false; break;
              }
            }
          }
          if(!match) break;
        }
        if(match) {
          const subX = x - snapX, subY = y - snapY;
          // Aplica a colisão configurada no metatile (0=Livre, 1=Sólido, 2=Plataforma, 3=Dano).
          // Preserva warps (4) já marcados manualmente - não fazem parte da definição do metatile.
          if(collisionMap[y * 32 + x] !== 4) collisionMap[y * 32 + x] = mt.collisions[subY * mt.w + subX] || 0;
          count++;
        }
      }
    }
    render();
    Project.status(`Recalculadas ${count} colisões`);
  }

  function selectMetatileObj(mt) {
    selectedMetatile = mt;
    ensureMetatileCollisions(selectedMetatile);
    document.querySelectorAll('#metatilePalette div').forEach(d => {
      d.style.borderColor = (mt && d.dataset.mtId === mt.id) ? '#ffcc00' : '#333';
    });
    updateSelectedInfo();
  }

  function updateSelectedInfo(){
    const info = document.getElementById('selectedInfo');
    const canv = document.getElementById('selectedPreview');
    if(!info || !canv) return;
    if(!selectedMetatile){ info.textContent = 'Nenhum'; const ctx = canv.getContext('2d'); ctx.fillStyle='#000'; ctx.fillRect(0,0,80,80); return; }
    ensureMetatileCollisions(selectedMetatile);
    info.innerHTML = `<b style="color:#fff">${selectedMetatile.name}</b> (${selectedMetatile.w}x${selectedMetatile.h})`;
    const cctx = canv.getContext('2d');
    cctx.fillStyle = '#000'; cctx.fillRect(0,0,80,80);
    const chrBuf = (typeof CHR !== 'undefined' && CHR.getBuffer) ? CHR.getBuffer() : (Project.data?.chr || new Uint8Array(8192));
    const pals = (typeof CHR !== 'undefined' && CHR.getPalettes) ? CHR.getPalettes() : (Project.data?.palettes || [[15,0,16,48]]);
    const pal = pals[activePalette] || pals[0];
    const w = selectedMetatile.w, h = selectedMetatile.h;
    const tilePxW = 80 / w, tilePxH = 80 / h;
    selectedMetatile.tiles.forEach((t, tIdx)=>{
      const off = t * 16; if(off + 16 > chrBuf.length) return;
      const gx = (tIdx % w), gy = Math.floor(tIdx / w);
      for(let py=0; py<8; py++){
        const p0 = chrBuf[off+py], p1 = chrBuf[off+py+8];
        for(let px=0; px<8; px++){
          const sh = 7-px, b0 = (p0>>sh)&1, b1 = (p1>>sh)&1, ci = (b1<<1)|b0;
          cctx.fillStyle = NES_PALETTE[pal[ci]];
          cctx.fillRect(gx*tilePxW + px*(tilePxW/8), gy*tilePxH + py*(tilePxH/8), (tilePxW/8)+0.5, (tilePxH/8)+0.5);
        }
      }
    });
    for(let gy=0; gy<h; gy++){
      for(let gx=0; gx<w; gx++){
        const subIdx = gy * w + gx;
        const colType = selectedMetatile.collisions[subIdx] || 0;
        if(colType > 0) {
          if(colType === 1) { cctx.fillStyle = 'rgba(255, 0, 0, 0.45)'; cctx.strokeStyle = '#ff3333'; }
          else if(colType === 2) { cctx.fillStyle = 'rgba(39, 174, 96, 0.5)'; cctx.strokeStyle = '#27ae60'; }
          else if(colType === 3) { cctx.fillStyle = 'rgba(142, 68, 173, 0.55)'; cctx.strokeStyle = '#9b59b6'; }
          else if(colType === 4) { cctx.fillStyle = 'rgba(211, 84, 0, 0.55)'; cctx.strokeStyle = '#e67e22'; }
          cctx.fillRect(gx*tilePxW, gy*tilePxH, tilePxW, tilePxH);
          cctx.strokeRect(gx*tilePxW + 0.5, gy*tilePxH + 0.5, tilePxW - 1, tilePxH - 1);
        }
        cctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        cctx.strokeRect(gx*tilePxW, gy*tilePxH, tilePxW, tilePxH);
      }
    }
    updateMetatileDefaultObjectUI();
  }

  // Mostra/popula o seletor de "objeto padrão" só quando o metatile selecionado tem algum
  // sub-tile marcado como Dano(3) ou Warp(4) - senão não faz sentido perguntar.
  function updateMetatileDefaultObjectUI(){
    const wrap = document.getElementById('mtDefaultObjWrap');
    const sel = document.getElementById('mtDefaultObjSelect');
    if(!wrap || !sel || !selectedMetatile) { if(wrap) wrap.style.display = 'none'; return; }
    const hasDano = selectedMetatile.collisions.some(c => c === 3);
    const hasWarp = selectedMetatile.collisions.some(c => c === 4);
    if(!hasDano && !hasWarp){ wrap.style.display = 'none'; return; }
    wrap.style.display = 'flex';
    const objs = (Project.data?.hitboxObjects || []).filter(o => (hasDano && o.kind === 'dano') || (hasWarp && o.kind === 'warp'));
    const cur = selectedMetatile.defaultHitboxObjectId || '';
    const iconFor = k => k==='dano' ? '🔻' : '🚪';
    sel.innerHTML = '<option value="">— nenhum (sem objeto padrão) —</option>' + objs.map(o => `<option value="${o.id}" ${o.id===cur?'selected':''}>${iconFor(o.kind)} ${o.name}</option>`).join('');
  }
  function setMetatileDefaultObject(id){
    if(!selectedMetatile) return;
    selectedMetatile.defaultHitboxObjectId = id || null;
  }

  /** Lê o bloco w×h em (ox,oy) do nametable (null se fora da tela). */
  function readNametableBlock(ox, oy, w, h){
    const tiles = [];
    for(let dy=0; dy<h; dy++){
      for(let dx=0; dx<w; dx++){
        const nx = ox + dx, ny = oy + dy;
        if(nx < 0 || nx >= 32 || ny < 0 || ny >= 30) return null;
        tiles.push(nametable[ny * 32 + nx] || 0);
      }
    }
    return tiles;
  }

  function blocksEqual(a, b){
    if(!a || !b || a.length !== b.length) return false;
    for(let i=0; i<a.length; i++) if((a[i]||0) !== (b[i]||0)) return false;
    return true;
  }

  /**
   * Flood no grid do metatile selecionado: troca todos os blocos conectados
   * iguais ao bloco clicado pelo metatile selecionado (mesmo princípio do fill do CHR).
   */
  function floodFillAt(tx, ty) {
    if(!selectedMetatile){
      alert('Selecione um metatile de destino na lista.');
      return;
    }
    ensureMetatileCollisions(selectedMetatile);
    const mt = selectedMetatile;
    const w = mt.w || 1, h = mt.h || 1;
    const snapX = Math.floor(tx / w) * w;
    const snapY = Math.floor(ty / h) * h;
    const targetBlock = readNametableBlock(snapX, snapY, w, h);
    if(!targetBlock) return;

    // Se o bloco clicado já é idêntico ao metatile selecionado, nada a fazer
    const replacement = [];
    for(let i=0; i<w*h; i++) replacement.push(mt.tiles[i] || 0);
    if(blocksEqual(targetBlock, replacement)) return;

    const queue = [{x: snapX, y: snapY}];
    const visited = new Set();
    while(queue.length > 0) {
      const curr = queue.shift();
      const cx = curr.x, cy = curr.y;
      const key = `${cx},${cy}`;
      if(visited.has(key)) continue;
      if(cx < 0 || cx + w > 32 || cy < 0 || cy + h > 30) continue;
      const block = readNametableBlock(cx, cy, w, h);
      if(!blocksEqual(block, targetBlock)) continue;
      visited.add(key);

      for(let dy=0; dy<h; dy++){
        for(let dx=0; dx<w; dx++){
          const nx = cx + dx, ny = cy + dy;
          const subIdx = dy * w + dx;
          nametable[ny * 32 + nx] = mt.tiles[subIdx] || 0;
          const attrX = Math.floor(nx/2), attrY = Math.floor(ny/2);
          const blockX = Math.floor(attrX/2), blockY = Math.floor(attrY/2);
          const attrIdx = blockY*8 + blockX;
          const shift = ((attrY%2)*2 + (attrX%2))*2;
          attributes[attrIdx] = (attributes[attrIdx] & ~(0x03 << shift)) | ((activePalette & 0x03) << shift);
          const col = mt.collisions[subIdx] || 0;
          collisionMap[ny * 32 + nx] = col;
          setHitboxInstanceAt(nx, ny, col, mt.defaultHitboxObjectId || null);
        }
      }
      queue.push({x: cx + w, y: cy});
      queue.push({x: cx - w, y: cy});
      queue.push({x: cx, y: cy + h});
      queue.push({x: cx, y: cy - h});
    }
    render();
  }

  // Grava/atualiza/remove a instância de hitbox numa posição, conforme o tipo de colisão
  // pintado ali. Repintar sempre usa o objeto padrão (se houver) - reatribuir individualmente
  // é feito depois, clicando na instância já colocada (ver reassignHitboxInstance).
  function setHitboxInstanceAt(x, y, colType, defaultObjId){
    const idx = hitboxInstances.findIndex(h => h.x === x && h.y === y);
    if(colType === 3 || colType === 4){
      if(idx >= 0) hitboxInstances[idx].hitboxObjectId = defaultObjId || null;
      else hitboxInstances.push({ x, y, hitboxObjectId: defaultObjId || null });
    } else if(idx >= 0){
      hitboxInstances.splice(idx, 1);
    }
  }
  function clearHitboxInstanceAt(x, y){
    const idx = hitboxInstances.findIndex(h => h.x === x && h.y === y);
    if(idx >= 0) hitboxInstances.splice(idx, 1);
  }
  function reassignHitboxInstance(x, y, hitboxObjectId){
    const idx = hitboxInstances.findIndex(h => h.x === x && h.y === y);
    if(idx >= 0) hitboxInstances[idx].hitboxObjectId = hitboxObjectId || null;
  }
  // Coleta, por flood (4 direções), todos os tiles conectados que têm o MESMO tipo de
  // colisão (3=Dano ou 4=Warp) do ponto de partida - 99% das vezes um grupo de tiles
  // vizinhos pintados juntos é o mesmo "objeto" (um espinho de 3 tiles, uma porta de 2x2...).
  function floodCollectSameCollisionType(startX, startY, colType){
    const visited = new Set();
    const queue = [{x:startX, y:startY}];
    const result = [];
    while(queue.length){
      const {x, y} = queue.shift();
      const key = x+','+y;
      if(visited.has(key)) continue;
      if(x < 0 || x >= 32 || y < 0 || y >= 30) continue;
      if(collisionMap[y*32+x] !== colType) continue;
      visited.add(key);
      result.push({x, y});
      queue.push({x:x+1,y}, {x:x-1,y}, {x,y:y+1}, {x,y:y-1});
    }
    return result;
  }
  // Abre uma escolha simples (por número, por enquanto) dos objetos compatíveis com o tipo
  // de colisão clicado, e reatribui TODOS os tiles vizinhos conectados do mesmo tipo de uma
  // vez (flood por padrão) - não precisa mais clicar tile por tile.
  function assignHitboxObjectAt(tx, ty){
    const colType = collisionMap[ty*32+tx];
    if(colType !== 3 && colType !== 4){ alert('Não há hitbox de Dano/Warp nesse tile. Pinte um primeiro (ferramenta Hitbox ou um metatile compatível).'); return; }
    const kind = colType === 4 ? 'warp' : 'dano';
    const kindLabel = kind === 'warp' ? 'Warp' : 'Dano';
    const objs = (Project.data?.hitboxObjects || []).filter(o => o.kind === kind);
    if(objs.length === 0){ alert(`Nenhum objeto de ${kindLabel} cadastrado ainda. Crie um em Programação > Objetos.`); return; }
    const region = floodCollectSameCollisionType(tx, ty, colType);
    const listStr = objs.map((o,i) => `${i+1}. ${o.name}`).join('\n');
    const answer = prompt(`${region.length} tile(s) conectado(s) - escolha o objeto de ${kindLabel}:\n${listStr}\n\nDigite o número:`, '');
    if(answer === null) return;
    const n = parseInt(answer);
    if(isNaN(n) || n < 1 || n > objs.length) return;
    region.forEach(({x, y}) => {
      const idx = hitboxInstances.findIndex(h => h.x === x && h.y === y);
      if(idx >= 0) hitboxInstances[idx].hitboxObjectId = objs[n-1].id;
      else hitboxInstances.push({ x, y, hitboxObjectId: objs[n-1].id });
    });
    render();
    Project.status(`${region.length} tile(s) agora usa(m) "${objs[n-1].name}"`);
  }

  function paintAt(mx, my, erasing = false, isAlt = false, isInitialClick = false) {
    if(!bgCanvas) return;
    const rect = bgCanvas.getBoundingClientRect();
    const scaleX = 512 / rect.width, scaleY = 480 / rect.height;
    const tx = Math.floor((mx * scaleX) / 16), ty = Math.floor((my * scaleY) / 16);
    if(tx < 0 || tx >= 32 || ty < 0 || ty >= 30) return;

    if(currentTool === 'text' || textMode){
      if(isInitialClick){
        let clickedOnText = false;
        for(let i = textLayers.length-1; i >=0; i--){
          const layer = textLayers[i];
          if(ty === layer.y && tx >= layer.x && tx < layer.x + layer.text.length){
            selectedTextIdx = i;
            movingTextMode = false;
            updateTextLayersUI();
            render();
            clickedOnText = true;
            break;
          }
        }
        if(!clickedOnText){
          textCursor.x = tx;
          textCursor.y = ty;
          selectedTextIdx = null;
          movingTextMode = false;
          updateCursorPos();
          updateTextLayersUI();
          render();
        }
      }
      return;
    }

    if(isAlt) { if(isInitialClick) pickMetatileAt(tx, ty); return; }

    if(currentTool === 'assign') { if(isInitialClick) assignHitboxObjectAt(tx, ty); return; }
    if(currentTool === 'hitbox') {
      const isHitboxFlood = document.getElementById('chkHitboxFlood')?.checked;
      if(isHitboxFlood) { if(isInitialClick) floodFillHitbox(tx, ty, erasing ? 0 : selectedCollisionType); }
      else { const ct = erasing ? 0 : selectedCollisionType; collisionMap[ty * 32 + tx] = ct; setHitboxInstanceAt(tx, ty, ct, null); render(); }
      return;
    }
    if(currentTool === 'flood' || currentTool === 'fill') {
      if(isInitialClick) floodFillAt(tx, ty);
      return;
    }
    if(currentTool === 'erase') { nametable[ty*32+tx] = 0; collisionMap[ty*32+tx] = 0; clearHitboxInstanceAt(tx, ty); render(); return; }
    if(currentTool === 'attr') {
      const attrX = Math.floor(tx/2), attrY = Math.floor(ty/2);
      const blockX = Math.floor(attrX/2), blockY = Math.floor(attrY/2);
      const attrIdx = blockY*8 + blockX;
      const shift = ((attrY%2)*2 + (attrX%2))*2;
      attributes[attrIdx] = (attributes[attrIdx] & ~(0x03 << shift)) | ((activePalette & 0x03) << shift);
      render(); return;
    }
    if(!selectedMetatile && !erasing) return;
    if(erasing){
      nametable[ty*32+tx] = 0; collisionMap[ty*32+tx] = 0; clearHitboxInstanceAt(tx, ty);
      // Apagar 1 tile cru pode furar um metatile 2x2 inteiro - invalida a
      // célula da grade (as 4 vizinhas dessa posição), não dá mais pra
      // comprimir essa célula (fallback cru no build).
      const gcx = Math.floor(tx/2), gcy = Math.floor(ty/2);
      if(gcx >= 0 && gcx < 16 && gcy >= 0 && gcy < 15) metatileGrid[gcy*16+gcx] = null;
      render(); return;
    }
    ensureMetatileCollisions(selectedMetatile);
    const mt = selectedMetatile;
    const snapX = Math.floor(tx / mt.w) * mt.w;
    const snapY = Math.floor(ty / mt.h) * mt.h;
    for(let dy=0; dy<mt.h; dy++){
      for(let dx=0; dx<mt.w; dx++){
        const nx = snapX + dx, ny = snapY + dy;
        if(nx < 0 || nx >= 32 || ny < 0 || ny >= 30) continue;
        const subIdx = dy * mt.w + dx;
        nametable[ny*32+nx] = (mt.tiles[subIdx] || 0);
        const attrX = Math.floor(nx/2), attrY = Math.floor(ny/2);
        const blockX = Math.floor(attrX/2), blockY = Math.floor(attrY/2);
        const attrIdx = blockY*8 + blockX;
        const shift = ((attrY%2)*2 + (attrX%2))*2;
        attributes[attrIdx] = (attributes[attrIdx] & ~(0x03 << shift)) | ((activePalette & 0x03) << shift);
        collisionMap[ny * 32 + nx] = mt.collisions[subIdx] || 0;
        setHitboxInstanceAt(nx, ny, mt.collisions[subIdx] || 0, mt.defaultHitboxObjectId || null);
      }
    }
    // Camada 8: só marca a célula da grade se o metatile é 2x2 E o carimbo
    // caiu certinho alinhado (snapX/snapY == tx/ty) - metatile legado de
    // outro tamanho, ou carimbo que "vazou" pra fora da tela, não vira 1
    // célula limpa (fica null = fallback cru pra essa célula no build).
    if(mt.w === 2 && mt.h === 2 && snapX === Math.floor(tx/2)*2 && snapY === Math.floor(ty/2)*2){
      const gcx = snapX/2, gcy = snapY/2;
      if(gcx >= 0 && gcx < 16 && gcy >= 0 && gcy < 15) metatileGrid[gcy*16+gcx] = mt.id;
    }
    render();
  }

  function attachEvents(){
    if(!bgCanvas) return;
    bgCanvas.addEventListener('mousedown', e => {
      isDrawing = true;
      const r = bgCanvas.getBoundingClientRect();
      const mx = e.clientX - r.left, my = e.clientY - r.top;
      if(currentTool === 'text'){
        const scaleX = 512 / r.width, scaleY = 480 / r.height;
        const tx = Math.floor((mx * scaleX) / 16), ty = Math.floor((my * scaleY) / 16);
        if(movingTextMode && selectedTextIdx !== null){
          moveTextLayerTo(selectedTextIdx, tx, ty, true);
          movingTextMode = false;
          Project.status("Texto movido");
          updateTextLayersUI();
        } else if(duplicatingTextMode && selectedTextIdx !== null){
          duplicateTextLayerAt(selectedTextIdx, tx, ty);
          duplicatingTextMode = false;
          Project.status("Texto duplicado");
        } else {
          paintAt(mx, my, e.shiftKey, e.altKey, true);
        }
      } else {
        paintAt(mx, my, e.shiftKey, e.altKey, true);
      }
    });
    bgCanvas.addEventListener('mousemove', e => {
      const r = bgCanvas.getBoundingClientRect();
      const mx = e.clientX - r.left, my = e.clientY - r.top;
      const tx = Math.floor((mx / r.width) * 32), ty = Math.floor((my / r.height) * 30);
      const hover = document.getElementById('hoverPos');
      if(hover) hover.textContent = `x:${tx} y:${ty} • Tile: ${formatTileAddr(nametable[ty*32+tx])} • Col: ${collisionMap[ty*32+tx]||0}`;
      if(isDrawing && currentTool !== 'text'){
        paintAt(mx, my, e.shiftKey, e.altKey, false);
      }
    });
    document.getElementById('selectedPreview')?.addEventListener('click', handlePreviewClick);
    document.getElementById('chkShowHitbox')?.addEventListener('change', render);
    document.getElementById('bgGridSelect')?.addEventListener('change', render);

    if(!globalEventsAttached){
      globalEventsAttached = true;
      window.addEventListener('mouseup', () => {
        isDrawing = false;
      });
      document.addEventListener('keydown', (e)=>{
        if(document.activeElement && document.activeElement.id === 'bgTextInput' && e.key === 'Enter'){
          e.preventDefault();
          insertText();
        }
      });
    }
  }

  function floodFillHitbox(tx, ty, newColType) {
    const targetType = collisionMap[ty * 32 + tx];
    if (targetType === newColType) return;
    const queue = [{x: tx, y: ty}];
    const visited = new Set();
    while(queue.length > 0) {
      const {x, y} = queue.shift();
      const key = `${x},${y}`;
      if(visited.has(key)) continue;
      if(x < 0 || x >= 32 || y < 0 || y >= 30) continue;
      if(collisionMap[y * 32 + x] !== targetType) continue;
      visited.add(key);
      collisionMap[y * 32 + x] = newColType;
      queue.push({x: x + 1, y: y});
      queue.push({x: x - 1, y: y});
      queue.push({x: x, y: y + 1});
      queue.push({x: x, y: y - 1});
    }
    render();
  }

  function pickMetatileAt(tx, ty) {
    const attrX = Math.floor(tx/2), attrY = Math.floor(ty/2);
    const blockX = Math.floor(attrX/2), blockY = Math.floor(attrY/2);
    const attrIdx = blockY*8 + blockX;
    const shift = ((attrY%2)*2 + (attrX%2))*2;
    activePalette = ((attributes[attrIdx]||0) >> shift) & 0x03;
    updateAttrPaletteUI();
    const boardTile = nametable[ty * 32 + tx];
    if (boardTile === 0) return;
    let mets = (typeof CHR !== 'undefined' && CHR.getMetatiles) ? CHR.getMetatiles() : (Project.data?.metatiles || []);
    mets = mets.filter(isValidForBG);
    let foundMt = null;
    for (let mt of mets) {
      const snapX = Math.floor(tx / mt.w) * mt.w;
      const snapY = Math.floor(ty / mt.h) * mt.h;
      let match = true;
      for(let dy=0; dy<mt.h; dy++){
        for(let dx=0; dx<mt.w; dx++){
          const nx = snapX + dx, ny = snapY + dy;
          if(nx < 32 && ny < 30) {
            if(nametable[ny * 32 + nx] !== mt.tiles[dy * mt.w + dx]) { match = false; break; }
          }
        }
        if(!match) break;
      }
      if(match) { foundMt = mt; break; }
    }
    if (foundMt) selectMetatileObj(foundMt);
  }

  /** Página BG da fase: NROM → 1; CNROM → phase.bg_page (legado: bank*2+1). */
  function phaseBgPage(phase){
    const mapper = (Project.data && Project.data.mapper === 3) ? 3 : 0;
    if(mapper !== 3) return 1;
    if(!phase) return 1;
    if(phase.bg_page !== undefined && phase.bg_page !== null) return phase.bg_page|0;
    return (phase.bank|0) * 2 + 1;
  }

  /**
   * Select de fases: texto = nome da fase, value = pág CHR de background daquela fase.
   * Várias fases podem apontar para a mesma página (ex.: fase 1 e 2 → pág 1).
   */
  function initChrPageSelect(){
    const sel = document.getElementById('bgChrPageSelect'); if(!sel) return;
    sel.innerHTML = '';
    const phases = (typeof Project !== 'undefined' && Project.data && Array.isArray(Project.data.phases))
      ? Project.data.phases
      : [];

    if(phases.length){
      phases.forEach((ph, i) => {
        const page = phaseBgPage(ph);
        const opt = document.createElement('option');
        opt.value = String(page);
        opt.textContent = ph.name || (`Fase ${i + 1}`);
        opt.dataset.phaseIndex = String(i);
        sel.appendChild(opt);
      });
      // Mantém a página atual se alguma fase a usa; senão usa a 1ª fase
      const pages = phases.map(phaseBgPage);
      if(!pages.includes(currentChrPage)) currentChrPage = pages[0];
      // Com values repetidos, selectedIndex aponta para a 1ª option com esse value
      sel.value = String(currentChrPage);
    } else {
      // Sem fases: fallback antigo (páginas ímpares de BG)
      const chrBuf = (typeof CHR !== 'undefined' && CHR.getBuffer) ? CHR.getBuffer() : (Project.data?.chr || new Uint8Array(8192));
      const totalPages = Math.max(1, Math.ceil(chrBuf.length / 4096));
      const oddPages = [];
      for(let i = 1; i < totalPages; i += 2) oddPages.push(i);
      if(oddPages.length === 0) oddPages.push(0);
      oddPages.forEach(i => {
        const opt = document.createElement('option');
        opt.value = String(i);
        opt.textContent = `Pág ${i}`;
        sel.appendChild(opt);
      });
      if(!oddPages.includes(currentChrPage)) currentChrPage = oddPages[0];
      sel.value = String(currentChrPage);
    }

    sel.onchange = (e) => {
      const v = parseInt(e.target.value, 10);
      switchToChrPage(isNaN(v) ? currentChrPage : v);
    };
  }

  // Troca a página de trabalho do CHR, preservando o desenho em progresso de cada página
  // separadamente (evita misturar metatiles de páginas diferentes numa mesma tela).
  // Cria uma tela em branco na página atual, pedindo o nome. Usada tanto pelo botão "Novo"
  // quanto automaticamente pelo bgChrPageSelect quando nenhuma tela salva usa a página escolhida.
  function promptNewCanvasForCurrentPage(){
    const name = prompt("Nome da nova tela:", `tela_pg${currentChrPage}`);
    nametable = new Array(960).fill(0); attributes = new Array(64).fill(0); collisionMap = new Array(960).fill(0); metatileGrid = new Array(240).fill(null);
    textLayers = []; hitboxInstances = [];
    if(name){ currentEntryId = 'scr_'+Date.now(); currentEntryName = name.trim(); currentEntryType = null; }
    else { currentEntryId = null; currentEntryName = ''; currentEntryType = null; }
    selectedTextIdx = null; movingTextMode = false; duplicatingTextMode = false; textUnderCache = {};
    updateTextLayersUI(); updateBGSelect(); render();
    return !!name;
  }

  // Troca a página de trabalho do CHR, sempre nessa ordem:
  // 1) atualiza a lista de metatiles pra nova página (incondicional);
  // 2) procura uma tela salva (background ou splash) que já use essa página e carrega ela;
  // 3) se não achar nenhuma, restaura um rascunho em progresso dessa página, ou aciona o
  //    mesmo fluxo do botão "Novo" (pede nome).
  function switchToChrPage(newPage){
    if(newPage === currentChrPage){ refreshMetatileList(); return; }
    pageDrafts[currentChrPage] = {
      nametable: [...nametable], attributes: [...attributes], collisionMap: [...collisionMap], metatileGrid: [...metatileGrid],
      textLayers: JSON.parse(JSON.stringify(textLayers)), hitboxInstances: JSON.parse(JSON.stringify(hitboxInstances))
    };
    currentChrPage = newPage;

    // 1) Sempre atualiza os metatiles primeiro, incondicionalmente.
    refreshMetatileList();

    // 2) Procura uma tela salva que já use essa página (sobe ou desce na lista, tanto faz).
    const bgs = Project.data?.backgrounds || [];
    const splashes = Project.data?.splashScreens || [];
    const matchesPage = e => (e.chrPage != null ? e.chrPage : inferChrPageFromNametable(e.nametable)) === newPage;
    const foundBg = bgs.find(matchesPage);
    const foundSplash = splashes.find(matchesPage);

    if(foundBg){ loadEntry('bg', foundBg.id); Project.status(`Página ${newPage}: background "${foundBg.name}" carregado`); return; }
    if(foundSplash){ loadEntry('splash', foundSplash.id); Project.status(`Página ${newPage}: splash "${foundSplash.name}" carregada`); return; }

    // 3) Nenhuma tela salva usa essa página - restaura rascunho em progresso, ou aciona "Novo".
    const draft = pageDrafts[newPage];
    if(draft){
      nametable = [...draft.nametable]; attributes = [...draft.attributes]; collisionMap = [...draft.collisionMap];
      metatileGrid = draft.metatileGrid ? [...draft.metatileGrid] : new Array(240).fill(null);
      textLayers = JSON.parse(JSON.stringify(draft.textLayers));
      hitboxInstances = JSON.parse(JSON.stringify(draft.hitboxInstances || []));
      currentEntryId = null; currentEntryName = ''; currentEntryType = null;
      selectedTextIdx = null; movingTextMode = false; duplicatingTextMode = false; textUnderCache = {};
      updateTextLayersUI(); updateBGSelect(); render();
      Project.status(`Página ${newPage}: rascunho anterior restaurado (ainda não salvo)`);
    } else {
      const named = promptNewCanvasForCurrentPage();
      Project.status(named ? `Página ${newPage}: nova tela "${currentEntryName}"` : `Página ${newPage}: tela em branco`);
    }
  }

  function refreshMetatileList(){
    const container = document.getElementById('metatilePalette'); if(!container) return;
    let mets = (typeof CHR !== 'undefined' && CHR.getMetatiles) ? CHR.getMetatiles() : (Project.data?.metatiles || []);
    mets = mets.filter(isValidForBG);
    container.innerHTML = '';
    const chrBuf = (typeof CHR !== 'undefined' && CHR.getBuffer) ? CHR.getBuffer() : (Project.data?.chr || new Uint8Array(8192));
    const startTile = currentChrPage * 256;
    const endTile = startTile + 256;
    const pageMetatiles = mets.filter(mt => { if(!mt.tiles || mt.tiles.length === 0) return true; return mt.tiles.some(t => t >= startTile && t < endTile); });
    if(pageMetatiles.length === 0){ container.innerHTML = `<div style="font-size:10px;color:#666;padding:8px">Nenhum metatile na pág</div>`; return; }
    pageMetatiles.forEach((mt, idx) => {
      const div = document.createElement('div');
      const isSelected = selectedMetatile && selectedMetatile.id === mt.id;
      div.style.cssText = `width:44px;height:44px;border:2px solid ${isSelected ? '#ffcc00' : '#333'};background:#000;cursor:pointer;display:flex;align-items:center;justify-content:center;image-rendering:pixelated`;
      div.title = mt.name || `mt_${idx}`;
      div.dataset.mtId = mt.id;
      const canv = document.createElement('canvas'); canv.width = 44; canv.height = 44;
      canv.style.cssText = 'display:block;width:100%;height:100%;image-rendering:pixelated;';
      const cctx = canv.getContext('2d');
      const w = mt.w || 2, h = mt.h || 2;
      const pals = (typeof CHR !== 'undefined' && CHR.getPalettes) ? CHR.getPalettes() : (Project.data?.palettes || [[15,0,16,48]]);
      const pal = pals[mt.palette || 0] || pals[0];
      mt.tiles.forEach((t, tIdx) => {
        const off = t * 16; if(off + 16 > chrBuf.length) return;
        const gx = (tIdx % w), gy = Math.floor(tIdx / w);
        for(let py=0; py<8; py++){
          const p0 = chrBuf[off+py], p1 = chrBuf[off+py+8];
          for(let px=0; px<8; px++){
            const sh = 7-px, b0 = (p0>>sh)&1, b1 = (p1>>sh)&1, ci = (b1<<1)|b0;
            cctx.fillStyle = NES_PALETTE[pal[ci]];
            cctx.fillRect(gx * (22 / (w / 2)) + px * (22 / (w / 2) / 8), gy * (22 / (h / 2)) + py * (22 / (h / 2) / 8), (22 / (w / 2) / 8) + 0.5, (22 / (h / 2) / 8) + 0.5);
          }
        }
      });
      div.appendChild(canv);
      div.onclick = () => { selectMetatileObj(mt); };
      container.appendChild(div);
    });
  }

  function getBgPalettes(){
    return (typeof CHR !== 'undefined' && CHR.getPalettes)
      ? CHR.getPalettes()
      : (Project.data?.palettes || [[15,0,16,48],[15,0,16,48],[15,0,16,48],[15,0,16,48]]);
  }

  function getBgActiveColorSlot(){
    if(typeof CHR !== 'undefined' && typeof CHR.getActiveSlot === 'function') return CHR.getActiveSlot();
    return 1;
  }

  function updateAttrPaletteUI(){
    const pals = getBgPalettes();
    const activeColorSlot = getBgActiveColorSlot();
    const container = document.getElementById('attrPaletteSelect');
    if(container){
      container.innerHTML = '';
      for(let i=0; i<4; i++){
        const box = document.createElement('div');
        box.style.cssText = `display:flex;gap:2px;padding:3px;border:2px solid ${i===activePalette?'#007acc':'transparent'};border-radius:4px;background:#111;cursor:pointer`;
        box.title = 'BG ' + i;
        box.onclick = () => {
          activePalette = i;
          if(typeof CHR !== 'undefined' && CHR.setActivePal) CHR.setActivePal(i);
          refreshBgPalettePanel();
          if(selectedMetatile) updateSelectedInfo();
        };
        for(let c=0; c<4; c++){
          const slot = document.createElement('div');
          const isActive = i===activePalette && c===activeColorSlot;
          slot.style.cssText = `width:20px;height:20px;background:${NES_PALETTE[pals[i] ? pals[i][c] : 0]};border:${isActive?'2px solid #ffcc00':'1px solid #444'};border-radius:2px;cursor:pointer`;
          slot.onclick = (e) => {
            e.stopPropagation();
            activePalette = i;
            if(typeof CHR !== 'undefined' && CHR.setActivePal) CHR.setActivePal(i);
            if(typeof CHR !== 'undefined' && CHR.setActiveSlot) CHR.setActiveSlot(c);
            refreshBgPalettePanel();
            if(selectedMetatile) updateSelectedInfo();
          };
          box.appendChild(slot);
        }
        container.appendChild(box);
      }
    }
    // Cores rápidas do slot ativo (0–3)
    const qc = document.getElementById('bgQuickColors');
    if(qc){
      qc.innerHTML = '';
      const pal = pals[activePalette] || pals[0] || [15,0,16,48];
      for(let c=0; c<4; c++){
        const isActive = c===activeColorSlot;
        const btn = document.createElement('div');
        btn.style.cssText = `width:32px;height:24px;background:${NES_PALETTE[pal[c]]};border:${isActive?'2px solid #ffcc00':'1px solid #555'};border-radius:3px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:10px;color:#000;font-weight:bold`;
        btn.textContent = String(c);
        btn.onclick = () => {
          if(typeof CHR !== 'undefined' && CHR.setActiveSlot) CHR.setActiveSlot(c);
          refreshBgPalettePanel();
        };
        qc.appendChild(btn);
      }
    }
    renderBgPaletteCompact(pals);
    renderBgMasterPalette();
  }

  function renderBgMasterPalette(){
    const grid = document.getElementById('bgMasterPaletteGrid');
    if(!grid || typeof NES_PALETTE === 'undefined') return;
    grid.innerHTML = '';
    let line = null;
    NES_PALETTE.forEach((col, idx) => {
      if(idx % 16 === 0){
        line = document.createElement('div');
        line.style.display = 'flex';
        line.style.gap = '2px';
        grid.appendChild(line);
      }
      const b = document.createElement('div');
      b.style.cssText = `width:18px;height:18px;background:${col};border:1px solid #333;border-radius:2px;cursor:pointer`;
      b.title = `NES $${idx.toString(16).padStart(2,'0').toUpperCase()}`;
      b.onclick = () => {
        if(typeof CHR === 'undefined' || !CHR.setPaletteColor) return;
        if(CHR.setActivePal) CHR.setActivePal(activePalette);
        CHR.setPaletteColor(activePalette, getBgActiveColorSlot(), idx);
        onPalettesChanged();
      };
      line.appendChild(b);
    });
  }

  function renderBgPaletteCompact(pals){
    const compact = document.getElementById('bgPaletteCompact');
    if(!compact) return;
    if(!pals) pals = getBgPalettes();
    compact.innerHTML = '';
    const group = document.createElement('div');
    group.className = 'chr-pal-compact-group';
    const lab = document.createElement('span');
    lab.className = 'chr-pal-compact-lab';
    lab.textContent = 'BG';
    group.appendChild(lab);
    for(let i=0; i<4; i++){
      const slot = document.createElement('div');
      slot.className = 'chr-pal-compact-slot' + (i===activePalette ? ' active' : '');
      slot.title = 'Atributo BG ' + i;
      slot.onclick = () => {
        activePalette = i;
        if(typeof CHR !== 'undefined' && CHR.setActivePal) CHR.setActivePal(i);
        refreshBgPalettePanel();
        if(selectedMetatile) updateSelectedInfo();
      };
      for(let c=0; c<4; c++){
        const sw = document.createElement('div');
        sw.style.background = NES_PALETTE[pals[i] ? pals[i][c] : 0];
        slot.appendChild(sw);
      }
      group.appendChild(slot);
    }
    compact.appendChild(group);
  }

  function refreshBgPalettePanel(){
    updateAttrPaletteUI();
    if(typeof CHR !== 'undefined' && CHR.refreshPaletteUI){
      CHR.refreshPaletteUI();
    }
  }

  function togglePalettePanel(){
    const panel = document.getElementById('bgPalettePanel');
    const btn = document.getElementById('bgPaletteToggle');
    if(!panel) return;
    panel.classList.toggle('collapsed');
    const open = !panel.classList.contains('collapsed');
    if(btn){
      btn.textContent = open ? '▾' : '▸';
      btn.title = open ? 'Recolher paletas' : 'Expandir paletas';
    }
    if(open){
      if(typeof CHR !== 'undefined' && CHR.setActivePal) CHR.setActivePal(activePalette);
      refreshBgPalettePanel();
    } else {
      renderBgPaletteCompact();
    }
  }

  function paletteBankAdd(){
    if(typeof CHR === 'undefined' || !CHR.paletteBankAdd) return;
    if(CHR.setActivePal) CHR.setActivePal(activePalette);
    CHR.paletteBankAdd();
    onPalettesChanged();
  }

  function paletteBankApply(){
    if(typeof CHR === 'undefined' || !CHR.paletteBankApply) return;
    if(CHR.setActivePal) CHR.setActivePal(activePalette);
    CHR.paletteBankApply();
    onPalettesChanged();
  }

  function paletteBankRename(){
    if(typeof CHR === 'undefined' || !CHR.paletteBankRename) return;
    CHR.paletteBankRename();
    onPalettesChanged();
  }

  function paletteBankDelete(){
    if(typeof CHR === 'undefined' || !CHR.paletteBankDelete) return;
    CHR.paletteBankDelete();
    onPalettesChanged();
  }

  function onPalettesChanged(){
    updateAttrPaletteUI();
    updateTextPaletteUI();
    if(typeof CHR !== 'undefined' && CHR.refreshPaletteUI) CHR.refreshPaletteUI();
    try{ render(); }catch(e){}
    if(selectedMetatile) try{ updateSelectedInfo(); }catch(e){}
  }

  function updateTextPaletteUI(){
    const container = document.getElementById('bgTextPalettes'); if(!container) return;
    const pals = (typeof CHR !== 'undefined' && CHR.getPalettes) ? CHR.getPalettes() : (Project.data?.palettes || [[15,0,16,48]]);
    container.innerHTML = '';
    for(let i=0; i<4; i++){
      const b = document.createElement('div');
      b.style.cssText = `width:20px;height:20px;border:2px solid ${i===textPalette?'#ffcc00':'#333'};cursor:pointer;background:${NES_PALETTE[pals[i] ? pals[i][1] : 0]};border-radius:2px`;
      b.onclick = () => { textPalette = i; updateTextPaletteUI(); };
      container.appendChild(b);
    }
  }

  function render(){
    if(!bgCtx || !bgCanvas) return;
    bgCtx.fillStyle = '#000'; bgCtx.fillRect(0,0,512,480);
    const chrBuf = (typeof CHR !== 'undefined' && CHR.getBuffer) ? CHR.getBuffer() : (Project.data?.chr || new Uint8Array(8192));
    const pals = (typeof CHR !== 'undefined' && CHR.getPalettes) ? CHR.getPalettes() : (Project.data?.palettes || [[15,0,16,48]]);
    for(let ty=0; ty<30; ty++){
      for(let tx=0; tx<32; tx++){
        const tileIdx = nametable[ty*32+tx] || 0;
        if(tileIdx === 0) continue;
        const off = tileIdx * 16; if(off + 16 > chrBuf.length) continue;
        const attrX = Math.floor(tx/2), attrY = Math.floor(ty/2);
        const blockX = Math.floor(attrX/2), blockY = Math.floor(attrY/2);
        const attrIdx = blockY*8 + blockX;
        const shift = ((attrY%2)*2 + (attrX%2))*2;
        const palIdx = (attributes[attrIdx] >> shift) & 0x03;
        const pal = pals[palIdx] || pals[0];
        for(let py=0; py<8; py++){
          const p0 = chrBuf[off+py], p1 = chrBuf[off+py+8];
          for(let px=0; px<8; px++){
            const sh = 7-px, b0 = (p0>>sh)&1, b1 = (p1>>sh)&1, ci = (b1<<1)|b0;
            bgCtx.fillStyle = NES_PALETTE[pal[ci]];
            bgCtx.fillRect(tx*16 + px*2, ty*16 + py*2, 2, 2);
          }
        }
      }
    }
    if(document.getElementById('chkShowHitbox')?.checked) {
      for(let ty=0; ty<30; ty++){
        for(let tx=0; tx<32; tx++){
          const type = collisionMap[ty*32+tx] || 0;
          if(type > 0) {
            if(type === 1) { bgCtx.fillStyle = 'rgba(255, 0, 0, 0.35)'; bgCtx.strokeStyle = '#ff3333'; }
            else if(type === 2) { bgCtx.fillStyle = 'rgba(39, 174, 96, 0.4)'; bgCtx.strokeStyle = '#27ae60'; } // Cor da Plataforma no canvas
            else if(type === 3) { bgCtx.fillStyle = 'rgba(142, 68, 173, 0.45)'; bgCtx.strokeStyle = '#9b59b6'; }
            else if(type === 4) { bgCtx.fillStyle = 'rgba(211, 84, 0, 0.45)'; bgCtx.strokeStyle = '#e67e22'; } // Cor da Warp no canvas
            bgCtx.fillRect(tx*16, ty*16, 16, 16);
            bgCtx.strokeRect(tx*16+0.5, ty*16+0.5, 15, 15);
          }
        }
      }
    }
    if(selectedTextIdx !== null && textLayers[selectedTextIdx]){
      const layer = textLayers[selectedTextIdx];
      bgCtx.strokeStyle = movingTextMode ? '#ffcc00' : '#00ff00';
      bgCtx.lineWidth = 2;
      bgCtx.setLineDash(movingTextMode ? [6,3] : []);
      bgCtx.strokeRect(layer.x*16, layer.y*16, layer.text.length*16, 16);
      bgCtx.setLineDash([]);
      bgCtx.fillStyle = '#ffcc00';
      bgCtx.fillRect(layer.x*16 - 4, layer.y*16 - 4, 8, 8);
    }
    if(textMode){
      bgCtx.strokeStyle = '#ffcc00'; bgCtx.lineWidth = 2;
      bgCtx.strokeRect(textCursor.x*16, textCursor.y*16, 16, 16);
      bgCtx.fillStyle = 'rgba(255,204,0,0.3)';
      bgCtx.fillRect(textCursor.x*16, textCursor.y*16, 16, 16);
    }
    const gridMode = document.getElementById('bgGridSelect')?.value || '2x2';
    if(gridMode !== 'none'){
      const step = gridMode === '1x1' ? 1 : gridMode === '4x4' ? 4 : 2;
      bgCtx.strokeStyle = step===1 ? 'rgba(255,255,255,0.08)' : 'rgba(255,204,0,0.2)';
      for(let y=0; y<=30; y+=step){ bgCtx.beginPath(); bgCtx.moveTo(0,y*16); bgCtx.lineTo(512,y*16); bgCtx.stroke(); }
      for(let x=0; x<=32; x+=step){ bgCtx.beginPath(); bgCtx.moveTo(x*16,0); bgCtx.lineTo(x*16,480); bgCtx.stroke(); }
    }
    updateStats();
  }

  function updateStats(){
    const el = document.getElementById('bgStats'); if(el) el.textContent = `${nametable.filter(t=>t!==0).length}/960`;
    const sol = document.getElementById('solidStats'); if(sol) sol.textContent = `${collisionMap.filter(c=>c!==0).length}`;
    const tc = document.getElementById('textCount'); if(tc) tc.textContent = textLayers.length;
  }

  function fillAllEmpty(){
    if(!selectedMetatile){ alert('Selecione um metatile'); return; }
    ensureMetatileCollisions(selectedMetatile);
    const mt = selectedMetatile;
    for(let y=0; y<30; y++){
      for(let x=0; x<32; x++){
        if(nametable[y*32+x] === 0) {
          const subIdx = (y % mt.h) * mt.w + (x % mt.w);
          nametable[y*32+x] = mt.tiles[subIdx];
          collisionMap[y*32+x] = mt.collisions[subIdx] || 0;
        }
      }
    }
    markMetatileGridFromTiles(mt);
    render();
  }

  // Camada 8 (compressão por metatile): "Preencher Vazios"/"Preencher Tela
  // Inteira" escrevem tile a tile (não célula a célula) - depois de
  // preencher, confere célula por célula (2x2) se as 4 posições batem
  // exatamente com o metatile usado; só marca metatileGrid nas que batem
  // (uma célula que já tinha outra coisa em parte dela, e por isso ficou
  // "misturada", fica null - fallback cru no build, não quebra nada).
  function markMetatileGridFromTiles(mt){
    for(let gy=0; gy<15; gy++){
      for(let gx=0; gx<16; gx++){
        let matches = true;
        for(let dy=0; dy<2 && matches; dy++){
          for(let dx=0; dx<2; dx++){
            const x = gx*2+dx, y = gy*2+dy;
            const subIdx = (y % mt.h) * mt.w + (x % mt.w);
            if(nametable[y*32+x] !== (mt.tiles[subIdx] || 0)) { matches = false; break; }
          }
        }
        if(matches) metatileGrid[gy*16+gx] = mt.id;
      }
    }
  }

  // FERRAMENTA TEMPORÁRIA DE MIGRAÇÃO (Camada 9): o backend agora exige
  // metatileGrid completo pra montar a tela - telas salvas antes dessa
  // funcionalidade só têm nametable/collisionMap crus. Essa função varre
  // as 240 células, e pra cada uma procura, entre os metatiles 2x2 de
  // background salvos no projeto, um cujos 4 tiles (TL,TR,BL,BR) batem
  // exatamente com o que já está pintado ali - entre os que batem nos
  // tiles, prefere o que TAMBÉM bate na colisão (desempate; útil quando 2
  // metatiles têm a mesma arte mas colisão diferente). Não sobrescreve
  // nametable/collisionMap, só preenche a grade nova. Remover esse botão
  // (e essa função) depois que não sobrar tela antiga pra migrar.
  function migrateLegacyScreen(){
    const mts = (Project.data?.metatiles || []).filter(mt => (mt.w||2)===2 && (mt.h||2)===2 && Array.isArray(mt.tiles) && mt.tiles.length>=4);
    if(!mts.length){ alert('Nenhum metatile 2×2 de background encontrado no projeto pra usar na migração.'); return; }
    let matched = 0, unmatched = 0;
    const unmatchedCells = [];
    for(let gy=0; gy<15; gy++){
      for(let gx=0; gx<16; gx++){
        const tiles = [], cols = [];
        for(let dy=0; dy<2; dy++){
          for(let dx=0; dx<2; dx++){
            const x = gx*2+dx, y = gy*2+dy;
            tiles.push(nametable[y*32+x] || 0);
            cols.push(collisionMap[y*32+x] || 0);
          }
        }
        let best = null;
        for(const mt of mts){
          const t = mt.tiles;
          if(t[0]!==tiles[0] || t[1]!==tiles[1] || t[2]!==tiles[2] || t[3]!==tiles[3]) continue;
          const c = mt.collisions || [];
          const colMatches = c[0]===cols[0] && c[1]===cols[1] && c[2]===cols[2] && c[3]===cols[3];
          if(!best) best = mt;
          if(colMatches){ best = mt; break; }
        }
        const gIdx = gy*16+gx;
        if(best){ metatileGrid[gIdx] = best.id; matched++; }
        else { metatileGrid[gIdx] = null; unmatched++; unmatchedCells.push(`(${gx},${gy})`); }
      }
    }
    render();
    if(unmatched){
      alert(`Migração parcial: ${matched}/240 células reconhecidas. ${unmatched} célula(s) sem metatile correspondente - crie/ajuste o metatile e repinte manualmente essas posições: ${unmatchedCells.slice(0,20).join(' ')}${unmatchedCells.length>20?'...':''}`);
    } else {
      alert(`Migração completa: as 240 células foram reconhecidas. Salve a tela pra gravar a grade nova.`);
    }
    if(typeof Project !== 'undefined' && Project.status) Project.status(`Migração: ${matched}/240 células reconhecidas`);
  }

  function fillEntireScreen(){
    if(!selectedMetatile) return;
    if(!confirm('Preencher a tela inteira? Isso sobrescreverá tudo.')) return;
    ensureMetatileCollisions(selectedMetatile);
    const mt = selectedMetatile;
    for(let y=0; y<30; y++){
      for(let x=0; x<32; x++){
        const subIdx = (y % mt.h) * mt.w + (x % mt.w);
        nametable[y*32+x] = mt.tiles[subIdx];
        collisionMap[y*32+x] = mt.collisions[subIdx] || 0;
      }
    }
    markMetatileGridFromTiles(mt);
    applyAttrToAll();
  }

  function applyAttrToAll(){
    for(let i = 0; i < 64; i++){
      let byte = 0;
      for(let p = 0; p < 4; p++) byte |= (activePalette & 0x03) << (p * 2);
      attributes[i] = byte;
    }
    render();
  }

  const TEXT_ACCENT_MAP = {'Á':65,'É':69,'Í':73,'Ó':79,'Ú':85,'Ç':67,'á':97,'é':101,'í':105,'ó':111,'ú':117,'ç':99};
  function charToTileIndex(ch, mode){
    if(mode === 'smb'){
      const upper = ch.toUpperCase();
      if(upper >= '0' && upper <= '9') return upper.charCodeAt(0) - 48;
      if(upper >= 'A' && upper <= 'Z') return 10 + (upper.charCodeAt(0) - 65);
      return 36;
    }
    let code = ch.charCodeAt(0);
    if(code > 127) code = TEXT_ACCENT_MAP[ch] || 32;
    return code % 256;
  }
  function charToNametableTile(ch, mode, page){
    const rel = charToTileIndex(ch, mode) % 256;
    const pg = (typeof page === 'number') ? page : currentChrPage;
    return pg * 256 + rel;
  }
  function setTextOffsetMode(mode){ textOffsetMode = (mode === 'smb') ? 'smb' : 'ascii'; }

  function positionsForRow(x, y, len){ const arr=[]; for(let i=0;i<len;i++) arr.push({x:x+i, y}); return arr; }

  // Devolve o nametable/atributos/grade de metatile ao estado de antes da
  // camada de texto ter sido escrita ali (Camada 8: sem isso, uma célula
  // que tinha virado "suja" só por causa do texto ficava presa suja pra
  // sempre, mesmo depois do texto ser apagado/movido dali).
  function restoreUnderText(layer){
    const snap = textUnderCache[layer.id]; if(!snap) return;
    snap.nt.forEach(({idx, tile}) => { nametable[idx] = tile; });
    snap.attr.forEach(({idx, byte}) => { attributes[idx] = byte; });
    if(snap.mtg) snap.mtg.forEach(({idx, val}) => { metatileGrid[idx] = val; });
    delete textUnderCache[layer.id];
  }
  // Guarda o que está no nametable/atributos/grade de metatile ANTES de
  // escrever o texto nessas posições, pra dar pra restaurar depois
  // (mover/editar/apagar).
  function captureUnderText(layer, positions){
    const nt = []; const attrBlocks = new Map(); const mtgCells = new Map();
    positions.forEach(({x,y}) => {
      if(x<0||x>=32||y<0||y>=30) return;
      const idx = y*32+x;
      nt.push({ idx, tile: nametable[idx] });
      const attrX=Math.floor(x/2), attrY=Math.floor(y/2);
      const attrIdx = Math.floor(attrY/2)*8+Math.floor(attrX/2);
      if(!attrBlocks.has(attrIdx)) attrBlocks.set(attrIdx, attributes[attrIdx]);
      const gx = Math.floor(x/2), gy = Math.floor(y/2);
      if(gx>=0 && gx<16 && gy>=0 && gy<15){
        const gIdx = gy*16+gx;
        if(!mtgCells.has(gIdx)) mtgCells.set(gIdx, metatileGrid[gIdx]);
      }
    });
    textUnderCache[layer.id] = {
      nt, attr: Array.from(attrBlocks, ([idx,byte]) => ({idx, byte})),
      mtg: Array.from(mtgCells, ([idx,val]) => ({idx, val}))
    };
  }
  function writeTextAt(layer, x, y){
    for(let i=0; i<layer.text.length; i++){
      const tx = x+i, ty = y;
      if(tx<0||tx>=32||ty<0||ty>=30) continue;
      nametable[ty*32+tx] = charToNametableTile(layer.text[i], layer.offset || 'ascii', layer.chrPage != null ? layer.chrPage : currentChrPage);
      const attrX=Math.floor(tx/2), attrY=Math.floor(ty/2);
      const attrIdx=Math.floor(attrY/2)*8+Math.floor(attrX/2);
      const shift=((attrY%2)*2+(attrX%2))*2;
      attributes[attrIdx] = (attributes[attrIdx] & ~(0x03<<shift)) | ((layer.pal & 0x03)<<shift);
      // Texto sobreposto (pós-compressão): o texto NÃO invalida mais a
      // célula de metatile - fica guardado à parte em textLayers (já
      // salvo normalmente) e escrito por cima em tempo de execução, depois
      // que a tela normal (via metatile) já foi desenhada. O metatile
      // original da célula continua válido/intacto o tempo todo - nada
      // pra restaurar aqui, nametable/attributes acima são só preview do
      // editor (não são mais lidos pelo NGC).
    }
    layer.x = x; layer.y = y;
  }

  function insertText(){
    const input = document.getElementById('bgTextInput'); if(!input) return;
    let text = input.value; if(!text) return;
    const selectEl = document.getElementById('bgTextOffsetSelect');
    const mode = selectEl ? selectEl.value : textOffsetMode;
    textOffsetMode = mode;
    const page = currentChrPage;
    const startX = Math.max(0, Math.min(32 - text.length, textCursor.x)), startY = textCursor.y;
    const layer = { text, x: startX, y: startY, pal: textPalette, offset: mode, chrPage: page, id: Date.now() };
    captureUnderText(layer, positionsForRow(startX, startY, text.length));
    writeTextAt(layer, startX, startY);
    textLayers.push(layer);
    selectedTextIdx = textLayers.length - 1;
    textCursor.x = Math.min(32, startX + text.length);
    updateCursorPos();
    input.value = ''; updateTextLayersUI(); input.focus(); render();
  }

  function moveTextLayerTo(idx, newX, newY, shouldRender = true){
    if(idx < 0 || idx >= textLayers.length) return;
    const layer = textLayers[idx];
    restoreUnderText(layer);
    newX = Math.max(0, Math.min(32 - layer.text.length, newX));
    newY = Math.max(0, Math.min(29, newY));
    captureUnderText(layer, positionsForRow(newX, newY, layer.text.length));
    writeTextAt(layer, newX, newY);
    if(shouldRender){ render(); updateTextLayersUI(); }
  }

  function editTextLayer(idx){
    if(idx <0 || idx >= textLayers.length) return;
    const layer = textLayers[idx];
    const newText = prompt("Editar texto:", layer.text);
    if(newText === null || newText === '') return;
    restoreUnderText(layer);
    layer.text = newText;
    const clampedX = Math.max(0, Math.min(32 - newText.length, layer.x));
    captureUnderText(layer, positionsForRow(clampedX, layer.y, newText.length));
    writeTextAt(layer, clampedX, layer.y);
    render(); updateTextLayersUI();
    Project.status(`Texto editado: "${newText}"`);
  }

  function deleteTextLayer(idx){
    if(idx <0 || idx >= textLayers.length) return;
    if(!confirm(`Deletar texto "${textLayers[idx].text}"?`)) return;
    const layer = textLayers[idx];
    restoreUnderText(layer);
    textLayers.splice(idx,1);
    if(selectedTextIdx === idx){ selectedTextIdx = null; movingTextMode = false; duplicatingTextMode = false; }
    else if(selectedTextIdx !== null && selectedTextIdx > idx) selectedTextIdx--;
    render(); updateTextLayersUI();
    Project.status("Texto deletado");
  }

  // Ativa o modo mover: o próximo clique no canvas manda o texto pra lá (não é mais drag).
  function toggleMoveMode(idx){
    if(selectedTextIdx !== idx){
      selectedTextIdx = idx;
      movingTextMode = true;
    } else {
      movingTextMode = !movingTextMode;
    }
    duplicatingTextMode = false;
    updateTextLayersUI();
    render();
    Project.status(movingTextMode ? "Modo mover ativo: clique no canvas no destino" : "Modo mover desativado");
  }

  function nudgeTextLayer(idx, dx, dy){
    if(idx <0 || idx >= textLayers.length) return;
    const layer = textLayers[idx];
    let newX = layer.x + dx, newY = layer.y + dy;
    newX = Math.max(0, Math.min(32 - layer.text.length, newX));
    newY = Math.max(0, Math.min(29, newY));
    moveTextLayerTo(idx, newX, newY, true);
  }

  // Ativa o modo duplicar: o próximo clique no canvas cria uma cópia do texto lá (o
  // original permanece intacto, ao contrário do mover).
  function startDuplicateTextMode(idx){
    if(idx <0 || idx >= textLayers.length) return;
    selectedTextIdx = idx;
    duplicatingTextMode = true;
    movingTextMode = false;
    updateTextLayersUI();
    Project.status("Duplicar: clique no canvas onde o novo texto deve começar");
  }

  function duplicateTextLayerAt(idx, x, y){
    if(idx <0 || idx >= textLayers.length) return;
    const src = textLayers[idx];
    const newLayer = { text: src.text, pal: src.pal, offset: src.offset, chrPage: src.chrPage, x: 0, y: 0, id: Date.now() };
    const clampedX = Math.max(0, Math.min(32 - newLayer.text.length, x));
    const clampedY = Math.max(0, Math.min(29, y));
    captureUnderText(newLayer, positionsForRow(clampedX, clampedY, newLayer.text.length));
    writeTextAt(newLayer, clampedX, clampedY);
    textLayers.push(newLayer);
    selectedTextIdx = textLayers.length - 1;
    render(); updateTextLayersUI();
  }

  function updateTextLayersUI(){
    const container = document.getElementById('bgTextLayers'); if(!container) return;
    if(textLayers.length === 0){ container.innerHTML = '<div style="font-size:11px;color:#666;text-align:center;padding:8px">Nenhum texto<br><span style="font-size:9px">Clique no canvas no modo Texto para posicionar o cursor</span></div>'; return; }
    container.innerHTML = '';
    textLayers.forEach((layer, i)=>{
      const isSelected = i === selectedTextIdx;
      const isMoving = isSelected && movingTextMode;
      const div = document.createElement('div');
      div.style.cssText = `display:flex;flex-direction:column;gap:4px;background:${isSelected? (isMoving ? '#332a00' : '#222') :'#111'};border:1px solid ${isSelected? (isMoving ? '#ffcc00' : '#00ff00') :'#333'};border-radius:4px;padding:6px;cursor:pointer`;
      
      const topRow = document.createElement('div');
      topRow.style.cssText = 'display:flex;align-items:center;gap:4px;';
      topRow.innerHTML = `<div style="flex:1;min-width:0"><div style="color:${isSelected?'#ffcc00':'#fff'};font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${layer.text}">"${layer.text}"</div><div style="font-size:9px;color:#888">x:${layer.x} y:${layer.y} • pal:${layer.pal} • ${(layer.offset||'ascii').toUpperCase()} • ${layer.text.length} chars</div></div>`;
      topRow.onclick = () => { selectedTextIdx = i; textCursor.x = layer.x + layer.text.length; textCursor.y = layer.y; movingTextMode = false; textOffsetMode = layer.offset || 'ascii'; const offSel=document.getElementById('bgTextOffsetSelect'); if(offSel) offSel.value = textOffsetMode; updateCursorPos(); updateTextLayersUI(); render(); };
      
      const btnRow = document.createElement('div');
      btnRow.style.cssText = 'display:flex;gap:3px;flex-wrap:wrap';
      btnRow.innerHTML = `
        <button class="btn-tool" onclick="event.stopPropagation(); BG.editTextLayer(${i})" style="font-size:9px;padding:2px 5px;background:#2980b9;color:#fff">✏ Editar</button>
        <button class="btn-tool" onclick="event.stopPropagation(); BG.toggleMoveMode(${i})" style="font-size:9px;padding:2px 5px;background:${isMoving?'#ffcc00;color:#000':'#444;color:#fff'}">${isMoving?'🟡 Clique no destino':'📦 Mover'}</button>
        <button class="btn-tool" onclick="event.stopPropagation(); BG.startDuplicateTextMode(${i})" style="font-size:9px;padding:2px 5px;background:${(isSelected&&duplicatingTextMode)?'#ffcc00;color:#000':'#27ae60;color:#fff'}">${(isSelected&&duplicatingTextMode)?'🟡 Clique no destino':'⎘ Duplicar'}</button>
        <button class="btn-tool" onclick="event.stopPropagation(); BG.deleteTextLayer(${i})" style="font-size:9px;padding:2px 5px;background:#c0392b;color:#fff">🗑</button>
        <div style="display:flex;gap:1px;margin-left:auto">
          <button class="btn-tool" onclick="event.stopPropagation(); BG.nudgeTextLayer(${i},0,-1)" style="font-size:8px;padding:1px 3px">↑</button>
          <button class="btn-tool" onclick="event.stopPropagation(); BG.nudgeTextLayer(${i},-1,0)" style="font-size:8px;padding:1px 3px">←</button>
          <button class="btn-tool" onclick="event.stopPropagation(); BG.nudgeTextLayer(${i},1,0)" style="font-size:8px;padding:1px 3px">→</button>
          <button class="btn-tool" onclick="event.stopPropagation(); BG.nudgeTextLayer(${i},0,1)" style="font-size:8px;padding:1px 3px">↓</button>
        </div>
      `;
      
      div.appendChild(topRow);
      div.appendChild(btnRow);
      container.appendChild(div);
    });
  }

  function updateBGSelect(){
    const sel = document.getElementById('bgSelect'); if(!sel) return; sel.innerHTML = '';
    const optNew = document.createElement('option'); optNew.value = ''; optNew.textContent = currentEntryType ? '— tela sem nome —' : `✨ ${currentEntryName || 'nova tela (não salva)'}`;
    sel.appendChild(optNew);
    const bgs = Project.data?.backgrounds || [];
    const splashes = Project.data?.splashScreens || [];
    bgs.forEach(b => { const o = document.createElement('option'); o.value = `bg:${b.id}`; o.textContent = `🗺 ${b.name}`; sel.appendChild(o); });
    splashes.forEach(s => { const o = document.createElement('option'); o.value = `sp:${s.id}`; o.textContent = `🎬 ${s.name}`; sel.appendChild(o); });
    sel.value = currentEntryType ? `${currentEntryType === 'bg' ? 'bg' : 'sp'}:${currentEntryId}` : '';
    sel.onchange = e => {
      const v = e.target.value; if(!v) return;
      const [type, id] = v.split(':');
      loadEntry(type === 'bg' ? 'bg' : 'splash', id);
    };
  }

  function isEntryEmpty(e){
    const nt = e?.nametable || [];
    const hasTiles = nt.some(t => t !== 0);
    const hasText = e?.textLayers && e.textLayers.length > 0;
    return !hasTiles && !hasText;
  }

  function pruneEmptyEntries(){
    if(!Project.data) return;
    if(Array.isArray(Project.data.backgrounds)){
      Project.data.backgrounds = Project.data.backgrounds.filter(b => b.id === currentEntryId || !isEntryEmpty(b));
    }
    if(Array.isArray(Project.data.splashScreens)){
      Project.data.splashScreens = Project.data.splashScreens.filter(s => s.id === currentEntryId || !isEntryEmpty(s));
    }
  }

  // Cria uma tela nova em branco, já pedindo o nome. Ela só é gravada em
  // Project.data.backgrounds/splashScreens quando "Salvar como..." for clicado - até lá
  // fica só em memória, sem tipo definido.
  function newCanvas(){
    const named = promptNewCanvasForCurrentPage();
    Project.status(named ? `Nova tela "${currentEntryName}" - use "Salvar como..." pra definir o tipo` : 'Tela em branco');
  }

  function clearBackground(){
    nametable = new Array(960).fill(0); attributes = new Array(64).fill(0); collisionMap = new Array(960).fill(0); metatileGrid = new Array(240).fill(null); textLayers = []; hitboxInstances = []; selectedTextIdx = null; render();
  }

  // Carrega uma tela salva (background ou splash) e sincroniza a página do CHR trabalhada
  // com a página que essa tela realmente usa - sempre, subindo ou descendo, sem depender de
  // comparação condicional (currentChrPage pode já ter sido pré-alterado por quem chamou).
  // Descobre a página do CHR usada por uma tela olhando os próprios tiles da nametable
  // (índice absoluto / 256 = página). Serve de reforço pro campo chrPage salvo - cobre
  // telas salvas antes desse campo existir, ou qualquer outra inconsistência nele.
  function inferChrPageFromNametable(nt){
    if(!nt) return null;
    for(const t of nt){ if(t) return Math.floor(t/256); }
    return null;
  }

  function loadEntry(type, id){
    const arr = type === 'splash' ? (Project.data?.splashScreens||[]) : (Project.data?.backgrounds||[]);
    const b = arr.find(e => e.id === id); if(!b) return;
    nametable = b.nametable ? [...b.nametable] : new Array(960).fill(0);
    attributes = b.attributes ? [...b.attributes] : new Array(64).fill(0);
    collisionMap = b.collisionMap ? [...b.collisionMap] : new Array(960).fill(0);
    // Camada 8: telas salvas antes dessa funcionalidade não têm grade -
    // fica null (fallback cru no build, igual telas com edição manual).
    metatileGrid = b.metatileGrid ? [...b.metatileGrid] : new Array(240).fill(null);
    textLayers = b.textLayers ? [...b.textLayers] : [];
    hitboxInstances = b.hitboxInstances ? JSON.parse(JSON.stringify(b.hitboxInstances)) : [];
    selectedTextIdx = null; textUnderCache = {}; movingTextMode = false; duplicatingTextMode = false;
    currentEntryId = b.id; currentEntryName = b.name; currentEntryType = type;
    const page = (b.chrPage != null) ? b.chrPage : inferChrPageFromNametable(nametable);
    if(page != null){
      currentChrPage = page;
      const pageSel = document.getElementById('bgChrPageSelect'); if(pageSel) pageSel.value = currentChrPage;
    }
    refreshMetatileList();
    updateBGSelect(); syncEntryTypeSelect(); updateTextLayersUI(); render();
  }

  function getSelectedEntryType(){
    const sel = document.getElementById('bgEntryTypeSelect');
    const v = sel?.value;
    return v === 'splash' ? 'splash' : 'bg';
  }

  function syncEntryTypeSelect(){
    const sel = document.getElementById('bgEntryTypeSelect');
    if(!sel) return;
    if(currentEntryType === 'splash' || currentEntryType === 'bg'){
      sel.value = currentEntryType;
    }
  }

  // Salva a tela atual como Background ou Splash (tipo do select acima do grid).
  // Se já existia com outro tipo, remove do array antigo e grava no novo.
  function saveEntryAs(type){
    if(!Project.data) return;
    if(!Project.data.backgrounds) Project.data.backgrounds = [];
    if(!Project.data.splashScreens) Project.data.splashScreens = [];
    if(!currentEntryId){ currentEntryId = 'scr_'+Date.now(); if(!currentEntryName) currentEntryName = `tela_${Date.now()}`; }

    const targetArr = type === 'splash' ? Project.data.splashScreens : Project.data.backgrounds;
    const otherArr = type === 'splash' ? Project.data.backgrounds : Project.data.splashScreens;
    if(currentEntryType && currentEntryType !== type){
      const oi = otherArr.findIndex(e => e.id === currentEntryId);
      if(oi >= 0) otherArr.splice(oi, 1);
    }
    const payload = { id: currentEntryId, name: currentEntryName, nametable:[...nametable], attributes:[...attributes], metatileGrid:[...metatileGrid], textLayers:[...textLayers], hitboxInstances: JSON.parse(JSON.stringify(hitboxInstances)), chrPage: currentChrPage, created: Date.now() };
    if(type === 'bg') payload.collisionMap = [...collisionMap];
    const idx = targetArr.findIndex(e => e.id === currentEntryId);
    if(idx >= 0) targetArr[idx] = { ...targetArr[idx], ...payload };
    else targetArr.push(payload);

    const wasConverted = currentEntryType && currentEntryType !== type;
    currentEntryType = type;
    pruneEmptyEntries(); updateBGSelect(); syncEntryTypeSelect();
    Project.status(wasConverted
      ? `"${currentEntryName}" convertido pra ${type === 'splash' ? 'Splash' : 'Background'}`
      : `${type === 'splash' ? 'Splash' : 'Background'} "${currentEntryName}" salvo`);
  }

  function saveCurrentEntry(){
    const type = getSelectedEntryType();
    if(!currentEntryName || !String(currentEntryName).trim()){
      const name = prompt('Nome da tela:', currentEntryName || '');
      if(name === null) return;
      const trimmed = name.trim();
      if(!trimmed){ alert('Informe um nome.'); return; }
      currentEntryName = trimmed;
    }
    saveEntryAs(type);
  }

  /** Clona a tela atual com novo nome (e novo id), mantendo o tipo do select. */
  function saveAsClone(){
    const type = getSelectedEntryType();
    const suggested = currentEntryName
      ? (String(currentEntryName).startsWith('Cópia de ')
          ? currentEntryName
          : `Cópia de ${currentEntryName}`)
      : '';
    const name = prompt('Salvar como (novo nome):', suggested);
    if(name === null) return;
    const trimmed = name.trim();
    if(!trimmed){ alert('Informe um nome.'); return; }
    currentEntryId = 'scr_' + Date.now();
    currentEntryName = trimmed;
    currentEntryType = null; // força insert novo
    saveEntryAs(type);
  }

  function loadAdjacentAfterDelete(type, removedId){
    const bgs = Project.data?.backgrounds || [];
    const splashes = Project.data?.splashScreens || [];
    if(type === 'bg'){
      if(bgs.length > 0){ loadEntry('bg', bgs[0].id); return; }
      if(splashes.length > 0){ loadEntry('splash', splashes[0].id); return; }
    } else {
      if(splashes.length > 0){ loadEntry('splash', splashes[0].id); return; }
      if(bgs.length > 0){ loadEntry('bg', bgs[0].id); return; }
    }
    currentEntryId = null; currentEntryName = ''; currentEntryType = null;
    nametable = new Array(960).fill(0); attributes = new Array(64).fill(0); collisionMap = new Array(960).fill(0); metatileGrid = new Array(240).fill(null);
    textLayers = []; hitboxInstances = []; updateTextLayersUI(); updateBGSelect(); render();
  }

  function deleteCurrentEntry(){
    if(!Project.data || !currentEntryId || !currentEntryType){ alert("Nenhuma tela salva selecionada para deletar."); return; }
    const arr = currentEntryType === 'bg' ? Project.data.backgrounds : Project.data.splashScreens;
    const idx = arr?.findIndex(e => e.id === currentEntryId);
    if(idx == null || idx < 0){ alert("Nenhuma tela salva selecionada para deletar."); return; }
    const nome = arr[idx].name || currentEntryId;
    if(!confirm(`Remover "${nome}"? Esta ação não pode ser desfeita.`)) return;
    arr.splice(idx, 1);
    loadAdjacentAfterDelete(currentEntryType, currentEntryId);
    Project.status(`Removido com sucesso`);
  }

  function renameCurrentEntry(){
    const current = (currentEntryName || '').trim();
    const name = prompt('Novo nome da tela:', current || '');
    if(name === null) return;
    const trimmed = name.trim();
    if(!trimmed){ alert('Nome inválido.'); return; }
    currentEntryName = trimmed;
    if(Project.data && currentEntryId && currentEntryType){
      const arr = currentEntryType === 'bg'
        ? Project.data.backgrounds
        : Project.data.splashScreens;
      const entry = arr?.find(e => e.id === currentEntryId);
      if(entry) entry.name = trimmed;
    }
    updateBGSelect();
    if(typeof Project !== 'undefined' && Project.status){
      Project.status(`Tela renomeada para "${trimmed}"`);
    }
  }

  return {
    init: buildHTML, setTool, setCollisionType, setAllSubTilesCollision, applyMetatileHitboxToCanvas, setMetatileDefaultObject,
    insertText, fillAllEmpty, fillEntireScreen, migrateLegacyScreen, applyAttrToAll, setTextOffsetMode,
    newCanvas, clearBackground, saveEntryAs, saveCurrentEntry, saveAsClone, deleteCurrentEntry, renameCurrentEntry, loadEntry,
    zoomIn, zoomOut,
    editTextLayer, deleteTextLayer, toggleMoveMode, nudgeTextLayer, startDuplicateTextMode, duplicateTextLayerAt, clearTextSelection,
    togglePalettePanel, paletteBankAdd, paletteBankApply, paletteBankRename, paletteBankDelete, onPalettesChanged,
    loadBackgrounds: (arr)=>{ if(Project.data) Project.data.backgrounds=arr; updateBGSelect(); try{ initChrPageSelect(); refreshMetatileList(); }catch(e){} },
    loadSplashScreens: (arr)=>{ if(Project.data) Project.data.splashScreens=arr; updateBGSelect(); try{ initChrPageSelect(); refreshMetatileList(); }catch(e){} },
    getBackgrounds: ()=> Project.data?.backgrounds||[],
    getSplashScreens: ()=> Project.data?.splashScreens||[],
    getNametable: ()=> [...nametable], getAttributes: ()=> [...attributes], getCollisionMap: ()=> [...collisionMap]
  };
})();
document.addEventListener('DOMContentLoaded', ()=>{ if(document.getElementById('mod-bg')?.classList.contains('active')) BG.init(); });